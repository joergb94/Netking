<div class="col-sm-12">
  <div class="row justify-content-between">
    <select class="form-control col-sm-3 search-query" id="typesearch">
      <option value="title" selected>Title</option>
      <option value="id">Id</option>
    </select>

    <input type="text" class="form-control col-sm-4 search-query" id="search">
    <select class="form-control text-center search-query col-sm-3" id="statusearch">
      <option value="1" selected>Actived</option>
      <option value="D">Delete</option>
    </select>
  </div>
</div>
<br>