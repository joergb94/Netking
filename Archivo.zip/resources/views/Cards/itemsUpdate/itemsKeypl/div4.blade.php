
    <div class="row justify-content-between bg-white {!! $card_style['divs_shape']  == 1?'div-rounded':''!!}">
        <div class="col-12">
            {!!$ci['card_detail']['description']!!}
        </div>
    </div>

