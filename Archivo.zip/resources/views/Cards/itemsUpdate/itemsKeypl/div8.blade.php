
    <div class="col-12 text-center mx-auto d-block">
        <a href="{{$ci['card_detail']['description']}}" class="btn btn-gray {{$btn_shape}} text-white btn-block" download>
            <div class="col-12">
                <h3 style="font-family:{{$text_font->name}};">{{$ci['card_detail']['name']}} <i class="fa fa-file-download"></i></h3>
            </div>
        </a>
    </div>

