
    <div class="col-12">
        <iframe class="{!! $card_style['divs_shape']  == 1?'div-rounded':''!!}"
                src="https://open.spotify.com/embed/playlist/{{$ci['card_detail']['name']}}?utm_source=generator" 
                width="100%" 
                height="380" 
                frameBorder="0" 
                allowfullscreen="" 
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture">
        </iframe>
    </div>
