
    <div class="col-12">
        <a class="btn btn-primary btn-block {{$btn_shape}}" target="_blank" href="{{$ci['card_detail']['description']}}" >
            <h3 style="font-family:{{$text_font->name}};">{{$ci['card_detail']['name']}}</h3>
        </a>
    </div>
   

