<div class="card">
  <div class="card-header">Contacto</div>
  <div class="card-body">
    <form id="contact-form">
        <div class="form-group">
            <label for="email">Email address:</label>
            <input type="email" class="form-control" placeholder="Enter email" id="email">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>