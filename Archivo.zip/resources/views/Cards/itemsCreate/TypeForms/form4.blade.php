<div class="card">
  <div class="card-header">Agregar Video de Tiktok</div>
  <div class="card-body">
    <form id="facebook-form">
        <div class="form-group">
            <label for="email">Codigo de Tiktok:</label>
            <textarea class="form-control" rows="5" id="comment"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>