<div class="card">
  <div class="card-header">Agregar Video de Youtube</div>
  <div class="card-body">
    <form id="facebook-form">
        <div class="form-group">
            <label for="email">Link del video:</label>
            <input type="email" class="form-control" placeholder="Enter email" id="email">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>