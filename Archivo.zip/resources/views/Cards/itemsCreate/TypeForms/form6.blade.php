<div class="card">
  <div class="card-header">Agregar publicacion de Twiter</div>
  <div class="card-body">
    <form id="facebook-form">
        <div class="form-group">
            <label for="email">Agregar link de Twiter:</label>
            <input type="email" class="form-control" placeholder="Enter email" id="email">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>