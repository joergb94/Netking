<div class="card">
  <div class="card-header">Agregar Publicacion de Facebook</div>
  <div class="card-body">
    <form id="facebook-form">
        <div class="form-group">
            <label for="email">codigo de Facebook:</label>
            <textarea class="form-control" rows="5" id="comment"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>