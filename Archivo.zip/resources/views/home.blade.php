@extends('layouts.app')

@section('content')
    <home-component></home-component>
    <br>
@endsection
