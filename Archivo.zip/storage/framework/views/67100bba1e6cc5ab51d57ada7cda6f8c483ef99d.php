<div class="main-header" data-background-color="purple">
			<!-- Logo Header -->
			<div class="logo-header">
				
				<a href="#" class="logo">
					<div class="col-sm-12 text-center">
						<h1 class="text-white">
							<strong>Keypl's</strong>
						</h1>
					</div>
					
				</a>
				<?php if(auth()->guard()->guest()): ?>
				<?php else: ?>
					<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon">
							<i class="fa fa-bars"></i>
						</span>
					</button>
					<button class="topbar-toggler more"><i class="fa fa-ellipsis-v"></i></button>
					<div class="navbar-minimize">
						<button class="btn btn-minimize btn-rounded">
							<i class="fa fa-bars"></i>
						</button>
					</div>
				<?php endif; ?>
				
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg">
                <?php if(auth()->guard()->guest()): ?>
                <div class="container-fluid">
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
					<?php if(Route::has('login')): ?>
                        <li class="nav-item dropdown hidden-caret">
							<a class="nav-link ropdown-toggle profile-pic" aria-expanded="false" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?> </a>
						</li>
					<?php endif; ?>
					<?php if(Route::has('register')): ?>
                        <li class="nav-item dropdown hidden-caret">
							<a class="nav-link ropdown-toggle profile-pic" aria-expanded="false"  href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
						</li>
					<?php endif; ?>
					</ul>
				</div>
                <?php else: ?>
				<div class="container-fluid">
					<div class="collapse" id="search-nav">
						<form class="navbar-left navbar-form nav-search mr-md-3">
							<div class="input-group">
								<div class="input-group-prepend">
									<button type="submit" class="btn btn-search pr-1">
										<i class="fa fa-search search-icon"></i>
									</button>
								</div>
								<input type="text" placeholder="Search ..." class="form-control">
							</div>
						</form>
					</div>
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<?php $__empty_1 = true; $__currentLoopData = $dm['data_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($menu->id == 4): ?>
						
					<?php else: ?>
					<li id="menu<?php echo e($menu->id); ?>" class="nav-item">
                        <a href="<?php echo e($menu->link); ?>" class="nav-link">
                            <i style="color:red;"
                                class="<?php echo e($menu->icon); ?>"></i><?php echo e($menu->name); ?></a>
                    </li>
					<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="nav-item active">
                        Sin Accessos
                    </li>
                <?php endif; ?>
						<li class="nav-item dropdown hidden-caret">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
								<div class="avatar-sm">
									<img src="<?php echo e((Auth::user()->image)?Auth::user()->path.Auth::user()->image:"https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"); ?>" alt="..." class="avatar-img rounded-circle">
								</div>
							</a>
							<ul class="dropdown-menu dropdown-user animated fadeIn">
								<li>
									<div class="user-box">
										<div class="avatar-lg"><img src="<?php echo e((Auth::user()->image)?Auth::user()->path.Auth::user()->image:"https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"); ?>" alt="image profile" class="avatar-img rounded"></div>
										<div class="u-text">
											<h4><?php echo e(Auth::user()->name); ?></h4>
											<p class="text-muted"><?php echo e(Auth::user()->email); ?></p><a href="/profile" class="btn btn-rounded btn-danger btn-sm">View Profile</a>
										</div>
									</div>
								</li>
								<li>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" id="logoutUs" href="" onclick="logout()"><?php echo e(__(' Logout')); ?></a>
									<form id="logout-form-d" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
										<?php echo csrf_field(); ?>
									</form>
								</li>
							</ul>
						</li>
						
					</ul>
				</div>
                <?php endif; ?>
			</nav>
			<!-- End Navbar -->
		</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/layouts/items/main-header.blade.php ENDPATH**/ ?>