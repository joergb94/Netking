<div class="card">
  <div class="card-header ">Links</div>
  <div class="card-body">
    <form id="contact-form">
      <div class="col-sm-12">
        <div class="row">
            <?php $__currentLoopData = $ns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6">
                <label for="<?php echo e($social['nsData']['name']); ?>"><?php echo e($social['nsData']['name']); ?></label>
                
                <div class="input-group mb-3 group-social">
                    <div class="input-group-prepend">
                        <a class="btn btn-social-icon <?php echo e($social['nsData']['btn_network']); ?>" href="#">
                            <span class="<?php echo e($social['nsData']['icon']); ?>"></span>
                        </a>
                    </div>
                    <input type="text" class="form-control form-control-sm n-social" onchange="Cards.save_asinc(<?php echo e($social['card_id']); ?>)" value ="<?php echo e(isset($social['nsUser'])?$social['nsUser']['url']:''); ?>"  id="<?php echo e($social['nsData']['name']); ?>" >
                    <input type="hidden"  class="n-button" value="<?php echo e($social['nsData']['btn_network']); ?>">
                    <input type="hidden"  class="n-icon" value="<?php echo e($social['nsData']['icon']); ?>">
                    <input type="hidden"  class="ns-id" value="<?php echo e($social['nsData']['id']); ?>">
                    <input type="hidden"  class="ns-detail-id" value="<?php echo e(isset($social['nsUser'])?$social['nsUser']['id']:''); ?>">
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </form>
  </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/TypeForms/form2.blade.php ENDPATH**/ ?>