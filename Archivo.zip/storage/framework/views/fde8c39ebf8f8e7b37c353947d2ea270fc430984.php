<div id="index_table">
  <div class="row">
    <!--table section-->
    <div class="col">
      <div class="col-sm-12">
            <div class="row">
              <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-sm-3">
                  <div class="card"  id="Card<?php echo e($Card->id); ?>" >

                    <div class="card-body text-center container-btn">
                    <button class="btn btn-warning btn-show-<?php echo e($Card['id']); ?> btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit(<?php echo e($Card['id']); ?>)"><i class='fas fa-edit'></i></button>
                       <button type="button" class="btn btn-danger btn-circle top-right btn-delete" style="display:none" onclick="Cards.delete(<?php echo e($Card['id']); ?>)" > <i class="fa fa-trash"></i></button>
                        <h4><?php echo e($Card->title); ?></h4>
                        <?php echo e($Card->subtitle); ?>

                    </div> 
                    <div class="card-footer text-center">
                        <?php echo $__env->make('Cards.items.buttons', ['Card' => $Card], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="col-sm-12">
                <div class="card text-center">
                    <br>
                    <h1 class="text-warning">
                      No Keypls
                    </h1>
                    <br>
                </div>
              </div>
              <?php endif; ?>
            </div>
      </div>
    </div>
    <!--pagination section-->
    <div class="col-sm-12">
      <div class="row">
        <div class="col-7">
          <div class="float-left">
            <?php echo $data->total(); ?> <?php echo e(trans_choice('Keypl|Keypls', $data->total())); ?>

          </div>
        </div>
        <!--col-->
        <div class="col-5">
          <div class="float-right">
            <?php echo $data->render(); ?>

          </div>
        </div>
        <!--col-->
      </div>
      <!--row-->
    </div>
  </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/items/table.blade.php ENDPATH**/ ?>