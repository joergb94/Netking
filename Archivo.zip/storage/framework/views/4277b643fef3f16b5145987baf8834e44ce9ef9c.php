<div class="row justify-content-between">
                    <div class="<?php echo e(($card_style['head_orientation'] == 1)?'col-4':'col-12'); ?> text-center" id="contend-image">
                        <img src="<?php echo e((isset($data['img_name']))? $data['img_path'].$data['img_name']:'https://www.w3schools.com/bootstrap4/cinqueterre.jpg'); ?>" class="<?php echo e($card_style['shape_image'] == 0?'rounded-circle':'rounded'); ?>" alt="Cinque Terre" width="100px" height="100px" id="imageProfile"> 
                    </div>
                    <div class="<?php echo e(($card_style['head_orientation'] == 1)?'col-8':'col-12'); ?> text-center" id="contend-title">
                        <br>
                        <div class="col-12" id='content-title'>
                            <?php if($data['large_text']): ?>
                                <h1 class="text-color" id="titlephone" style="color:<?php echo $data['color']; ?>; font-family:<?php echo e($text_font->name); ?>;">
                                <?php if(isset($ci['card_detail']['name'])): ?><?php echo e($ci['card_detail']['name']); ?><?php endif; ?>
                            </h1>
                            <?php else: ?>
                                <h2 class="text-color" id="titlephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php if(isset($ci['card_detail']['name'])): ?><?php echo e($ci['card_detail']['name']); ?><?php endif; ?></h2>
                            <?php endif; ?> 
                        </div>
                        <?php if($data['large_text']): ?>
                            <p class="text-color" id="namephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php echo e($user['name']); ?></p>
                        <?php else: ?>
                            <h2 class="text-color" id="namephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php echo e($user['name']); ?></h2>
                        <?php endif; ?>
                        
                        <h6 class="text-color" id="subephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php if(isset($ci['card_detail']['description'])): ?><?php echo e($ci['card_detail']['description']); ?><?php endif; ?></h6>
                    </div>
                
</div>
<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div1.blade.php ENDPATH**/ ?>