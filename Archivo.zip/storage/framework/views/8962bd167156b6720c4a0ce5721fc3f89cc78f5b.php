<div class="row justify-content-between">
    <div class="col-12 text-center mx-auto d-block">
        <a href="<?php echo e($ci['card_detail']['description']); ?>" class="btn btn-gray <?php echo e($btn_shape); ?> text-white btn-block" download>
            <div class="col-12">
                <h3 style="font-family:<?php echo e($text_font->name); ?>;"><?php echo e($ci['card_detail']['name']); ?> <i class="fa fa-file-download"></i></h3>
            </div>
        </a>
    </div>
</div>
<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div8.blade.php ENDPATH**/ ?>