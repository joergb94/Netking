<div class="row justify-content-between">
    <div class="col-12 col-sm-10 text-center mx-auto d-block">
        <iframe 
            class="mx-auto d-block"
            src="<?php echo e($ci['card_detail']['name']); ?>" 
            height="<?php echo e($ci['card_detail']['item_data']); ?>" 
            style="border:none;overflow:hidden; width:100%;" 
            scrolling="no" 
            frameborder="0" 
            allowfullscreen="true" 
            allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share">
        </iframe>
    </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div5.blade.php ENDPATH**/ ?>