<div class="row justify-content-between">
    <iframe 
        class="<?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?>" 
        width="100%" 
        height="315" 
        src="https://www.youtube.com/embed/<?php echo e($ci['card_detail']['name']); ?>" 
        title="YouTube video player" 
        frameborder="0" 
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen
    >
    </iframe>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div3.blade.php ENDPATH**/ ?>