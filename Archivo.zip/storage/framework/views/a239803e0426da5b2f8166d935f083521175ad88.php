<div class="col-sm-12" id='data-card'>
  <form id="card-form-style" >
          <div class="form-group">
            <h3>Forma de imagen:</h3>
              <div class="col-sm-12">
                    <div class="col-sm-12 mx-auto d-block">
                      <div class="row">
                          <div class="col-sm-6">
                              <ul>
                                <li>
                                  <input type="checkbox" class="image-shapes shape1" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)"  value="1"  id="myCheckbox1" <?php echo $card_style['shape_image']  == 1?'checked disabled':''; ?>/>
                                  <label for="myCheckbox1"><img class="rounded" src="<?php echo e(asset('img/shape.jpg')); ?>" /></label>
                                </li>
                              </ul>
                          </div>
                          <div class="col-sm-6">
                            <ul>
                              <li>
                                <input type="checkbox" class="image-shapes shape0" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" value="0" id="myCheckbox2" <?php echo $card_style['shape_image']  == 0?'checked disabled':''; ?> />
                                <label for="myCheckbox2"><img class="rounded-circle" src="<?php echo e(asset('img/shape.jpg')); ?>" /></label>
                              </li>
                            </ul>
                          </div>
                      </div>
                    </div>
                      <input type="hidden" name="shape_image" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" id="shape_image"  value="<?php echo e($card_style['shape_image']); ?>">
              </div>
          </div>
          <div class="form-group">
            <h3>Orientation:</h3>
              <div class="col-sm-12">
                    <div class="col-sm-12 mx-auto d-block">
                      <div class="row">
                          <div class="col-sm-6">
                              <ul>
                                <li>
                                  <input type="checkbox" class="head_orientation orientation0"  value="0"  onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" id="myCheckbox3" <?php echo $card_style['head_orientation']  == 0?'checked disabled':''; ?>/>
                                  <label for="myCheckbox3">
                                    <div class="col-12">
                                      <div class="row">
                                      <div class="col-12">
                                        <div class="col-12">
                                        <img class="rounded  mx-auto d-block image-form" src="<?php echo e(asset('img/shape.jpg')); ?>" />
                                        </div>
                                      </div>
                                      <div class="col-12 text-center">
                                          <h4 class="d-none d-sm-block"><strong>________</strong></h4>
                                          <h4 class="d-none d-sm-block"><strong>________</strong></h4>
                                          <h4 class="d-block d-sm-none">Vertical</h4>
                                      </div>
                                      </div>
                                    </div>
                                  </label>
                                </li>
                              </ul>
                          </div>
                          <div class="col-sm-6">
                            <ul>
                              <li>
                                <input type="checkbox" class="head_orientation orientation1" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" value="1" id="myCheckbox4" <?php echo $card_style['head_orientation']  == 1?'checked disabled':''; ?> />
                                <label for="myCheckbox4">
                                  <div class="col-12">
                                    <br>
                                      <div class="row">
                                        <div class="col-12 col-sm-4">
                                          <div class="col-12">
                                            <img class="rounded image-form mx-auto d-block" src="<?php echo e(asset('img/shape.jpg')); ?>" />
                                          </div>
                                        </div>
                                        <div class="col-12 col-sm-8">
                                          <h4 class="d-none d-sm-block"><strong>________</strong></h4>
                                          <h4 class="d-none d-sm-block"><strong>________</strong></h4>
                                          <h4 class="d-block d-sm-none">Horizontal</h4>
                                        </div>
                                      </div>
                                    <br>
                                  </div>
                                </label>
                              </li>
                            </ul>
                          </div>
                      </div>
                    </div>
                    <input type="hidden" id="head_orientation"  onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="head_orientation"  value="<?php echo e($card_style['head_orientation']); ?>">
              </div>
          </div>
          <div class="form-group">
            <label>Image Profile:</label>
              <input type="file" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" class="form-control-file border" id="image" name="image">
          </div>
          <div class="form-group">
            <h3>Forma de los Bloques:</h3>
              <div class="col-sm-12">

                <ul class="col-sm-12 mx-auto d-block list-group">
                              <li class="list-group-item col-12">
                                    <input type="checkbox" class="div-shapes shapeDiv0" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)"  value="0"  id="myCheckbox5" <?php echo $card_style['divs_shape']  == 0?'checked disabled':''; ?>/>
                                    <label class="col-12" for="myCheckbox5">
                                      <div class="col-12 text-center bg-secondary text-dark size-q">
                                              <h6>Example keypls</h6>
                                      </div>
                                  </label>
                              </li>
                                <li class="list-group-item col-12">
                                  <input type="checkbox" class="div-shapes shapeDiv1" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" value="1" id="myCheckbox6"  <?php echo $card_style['divs_shape']  == 1?'checked disabled':''; ?>/>
                                  <label class="col-12" for="myCheckbox6">
                                      <div class="col-12 div-rounded text-center bg-secondary text-dark size-c">
                                            <h6>Example keypls</h6>
                                      </div>
                                  </label>
                                </li>

                            </ul>
                   
                            <input type="hidden" name="divs_shape" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" id="div-shapes"  value="<?php echo e($card_style['divs_shape']); ?>">
              </div>
          </div>
          <div class="form-group">
            <h3>Forma de los Botones:</h3>
              <div class="col-sm-12">
                <div class="row">
                            <div class="col-sm-4" hidden>
                                <ul>
                                  <li>
                                    <input type="checkbox" class="buttons_shape shapeButton1" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" value="1" id="myCheckbox7"  <?php echo $card_style['buttons_shape']  == 1?'checked disabled':''; ?> />
                                    <label for="myCheckbox7"><button type="button" class="btn btn-fab-r bg-secondary text-dark text-center">Basic</button></label>
                                  </li>
                                </ul>
                            </div>
                            <div class="col-sm-6">
                              <ul>
                                <li>
                                  <input type="checkbox" class="buttons_shape shapeButton2" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" value="2" id="myCheckbox8"  <?php echo $card_style['buttons_shape']  == 2?'checked disabled':''; ?> />
                                  <label for="myCheckbox8"><button type="button" class="btn btn-rounded btn-block bg-secondary text-dark">Basic</button></label>
                                </li>
                              </ul>
                            </div>
                            <div class="col-sm-6">
                              <ul>
                                  <li>
                                    <input type="checkbox" class="buttons_shape shapeButton3" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)"  value="3"  id="myCheckbox9" <?php echo $card_style['buttons_shape']  == 3?'checked disabled':''; ?> />
                                    <label for="myCheckbox9"><button type="button" class="btn bg-secondary btn-block text-dark" >Basic</button></label>
                                  </li>
                              </ul>
                            </div>
                </div>
                      <input type="hidden" name="buttons_shape" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" id="buttons_shape"  value="<?php echo e($card_style['buttons_shape']); ?>">
              </div>
          </div>
          <div class="form-group">
                <div class="row">
                <div class="col-sm-6">
                  <label>Color Text:</label>
                  <input onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)"  type="text" id="colorInput" name='color' data-jscolor="" class="form-control" value="<?php echo e((isset($data['color']))?$data['color']:''); ?>">
                </div>
                <div class="col-sm-6">
                  <label>Backgroud Color:</label>
                  <input onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)"  type="text" id="background_image_color" name='background_image_color' data-jscolor="" class="form-control" value="<?php echo e((isset($data['background_image_color']))?$data['background_image_color']:''); ?>">
                </div>
                </div>
          </div>
          <div class="form-group">
            <div class="row">
              <div class="col-sm-6">
                <label>Size Text Header:</label>
                <div class="custom-control custom-checkbox">
                    <select  id="largeTitle" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="large_text" class="form-control">
                      <?php if(isset($data)): ?>
                        <?php if($data['large_text'] == 1): ?>
                        <option value="0">Medium</option>
                        <option value="1" selected>Big</option>
                        <?php else: ?>
                        <option value="0" selected>Medium</option>
                        <option value="1">Big</option>
                        <?php endif; ?>
                        <?php else: ?>
                        <option value="0" selected>Medium</option>
                        <option value="1">Big</option>
                        <?php endif; ?>
                      
                    </select>
                </div>
              </div>
              <div class="col-sm-6">
                <label>Text Style:</label>
                <select onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="text_style_id" id="text_style" class="form-control">
                  <?php $__empty_1 = true; $__currentLoopData = $text_styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text_style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($text_style['id']); ?>"><?php echo e($text_style['name']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <option value="">No style</option>
                  <?php endif; ?>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label>Theme:</label>
            <input type="text" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" id="theme" name="theme" value="" class="form-control">
          </div>
          <div class="form-group">
            <label>Backgroud:</label>
            <select name="background" id="background" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" class="form-control">
              <?php $__empty_1 = true; $__currentLoopData = $backgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php if(isset($data['background_image_id'])): ?>
                      <?php if($item['id'] == $data['background_image_id']): ?>
                      <option value="<?php echo e($item['id']); ?>" selected><?php echo e($item['name']); ?></option>
                      <?php else: ?>
                      <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                      <?php endif; ?>
                  <?php else: ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <option value="">No data</option> 
              <?php endif; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Location:</label>
            <input type="text" id="ocation" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="location" value="<?php echo e((isset($data['location']))?$data['location']:''); ?>" class="form-control">
          </div>
  </form>
 </div>       
<script>
    var myPicker = new JSColor('#colorInput', {format:'hex'});
    var myPicker2 = new JSColor('#background_image_color', {format:'hex'});

     $('.image-shapes').click(function(){
         let shape = $(this).val();
         
        let checDisabled1 = document.getElementById("myCheckbox1")
                              checDisabled1.disabled = shape == 1 ?true:false;

        let checDisabled2 = document.getElementById("myCheckbox2")
                              checDisabled2.disabled = shape == 0 ?true:false;

        $('#shape_image').val(shape);

        $(".image-shapes").prop("checked", false);
        $(".shape"+shape).prop("checked", true);
     });

     $('.head_orientation').click(function(){
         let orientation = $(this).val();

         let checDisabled3 = document.getElementById("myCheckbox3")
                              checDisabled3.disabled = orientation == 0 ?true:false;

        let checDisabled4 = document.getElementById("myCheckbox4")
                              checDisabled4.disabled = orientation == 1 ?true:false;
                            
                                    

        $('#head_orientation').val(orientation);

        $(".head_orientation").prop("checked", false);
        $(".orientation"+orientation).prop("checked", true);
     
     });

     $('.div-shapes').click(function(){
         let divs = $(this).val();

         let checDisabled5 = document.getElementById("myCheckbox5")
                              checDisabled5.disabled = divs == 0 ?true:false;

        let checDisabled6 = document.getElementById("myCheckbox6")
                              checDisabled6.disabled = divs == 1 ?true:false;
                            
                                    

        $('#div-shapes').val(divs);

        $(".div-shapes").prop("checked", false);
        $(".shapeDiv"+divs).prop("checked", true);
     
     });
      
     $('.buttons_shape').click(function(){
         let buttons = $(this).val();
        console.log(buttons);  

        $('#buttons_shape').val(buttons);
        $(".buttons_shape").prop("checked", false);
        $(".buttons_shape").prop("disabled", false);
 
        $(".shapeButton"+buttons).prop("checked", true);
        $(".shapeButton"+buttons).prop("disabled", true);
     
     });
</script><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/cardForm.blade.php ENDPATH**/ ?>