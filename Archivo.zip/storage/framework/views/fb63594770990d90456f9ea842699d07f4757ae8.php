<div class="col-sm-12">
    <br>
    <div class="col-sm-12">
        <div class="row justify-content-between">
            <div class="<?php echo ($card_style['head_orientation'] == 0)?'col-sm-4':'col-sm-12'; ?> text-center" id="contend-image">
                <img src="<?php echo e((isset($data['img_name']))? $data['img_path'].$data['img_name']:'https://www.w3schools.com/bootstrap4/cinqueterre.jpg'); ?>" class="<?php echo e($card_style['shape_image']?'rounded-circle':'rounded'); ?>" alt="Cinque Terre" width="100px" height="100px" id="imageProfile"> 
            </div>
            <div class="<?php echo ($card_style['head_orientation'] == 0)?'col-sm-8':'col-sm-12'; ?> text-center" id="contend-title">
                <br>
                <div class="col-sm-12" id='content-title'>
                    <?php if($data['large_text']): ?>
                        <h1 class="text-color" id="titlephone" style="color:<?php echo $data['color']; ?>"><?php if(isset($data['title'])): ?><?php echo e($data['title']); ?><?php endif; ?></h1>
                    <?php else: ?>
                        <h2 class="text-color" id="titlephone" style="color:<?php echo $data['color']; ?>"><?php if(isset($data['title'])): ?><?php echo e($data['title']); ?><?php endif; ?></h2>
                    <?php endif; ?> 
                </div>
                <?php if($data['large_text']): ?>
                    <p class="text-color" id="namephone" style="color:<?php echo $data['color']; ?>"><?php echo e($user['name']); ?></p>
                <?php else: ?>
                    <h2 class="text-color" id="namephone" style="color:<?php echo $data['color']; ?>"><?php echo e($user['name']); ?></h2>
                <?php endif; ?>
                
                <h6 class="text-color" id="subephone" style="color:<?php echo $data['color']; ?>"><?php if(isset($data['subtitle'])): ?><?php echo e($data['subtitle']); ?><?php endif; ?></h6>
            </div>
           
        </div>
    </div>
    <br>
    <div class="row justify-content-between">
        <div class="col-sm-12 text-center" id="social">
            <?php if(isset($data['card_network'])): ?>
                <?php $__currentLoopData = $data['card_network']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <a class="btn btn-social-icon <?php echo e($item['social_network']['btn_network']); ?>" href="<?php echo e($item['url']); ?>">
                    <i class="<?php echo e($item['social_network']['icon']); ?>"></i>
                  </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/keypl.blade.php ENDPATH**/ ?>