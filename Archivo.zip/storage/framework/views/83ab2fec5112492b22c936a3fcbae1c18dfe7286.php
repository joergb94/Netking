<div class="row" style="padding-top: 3%; padding-bottom: 10%">
    <div class="card col-sm-12" id="card" >
        <button class="btn btn-warning btn-circle top-right btn-update" id="button-edit" data-toggle="tooltip" title="Editar Perfil!" onclick="Profile.edit()" ><i class='fas fa-edit'></i></button>
        <div class="card-header">
          Detalles de usuario
        </div>
        <div class="card-body" id="cardBody">
          <h5 class="card-title">Correo:</h5>
          <p class="card-text"><?php echo e($dm['user']['email']); ?></p>
         <h5 class="card-title">Nickname:</h5>
         <p class="card-text"><?php echo e($dm['user']['nickname']); ?></p>
         <h5 class="card-title">Telefono:</h5>
         <p class="card-text"><?php echo e($dm['user']['phone']); ?></p>
         <h5 class="card-title">Tipo de membresia:</h5>
         <p class="card-text">
             <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <?php echo e($item['type_memberships']['membership']); ?>,
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 ninguna membresia
             <?php endif; ?>
         </p>
        </div>
        <div class="card-footer text-muted" id="cardFooter">
          
        </div>
      </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Profile/items/profileBody.blade.php ENDPATH**/ ?>