

<div class="btn-group col-sm-12" id="btn-group-<?php echo e($data['card_detail']->id); ?>">
    <button type="button" class="btn <?php echo e($data['item']->style); ?> btn-block"   onclick="transactions.toggle(<?php echo e($data['card_detail']->id); ?>)" >
        <h2><?php echo e($data['item']->name); ?> <i class="<?php echo e($data['item']->icon); ?>"></i></h2>
    </button>
    <button type="button" class="btn <?php echo e($data['item']->style); ?> delete" id="btn-delete-<?php echo e($data['card_detail']->id); ?>" style="display:none"  onclick="Cards.delete_item(<?php echo e($data['card_detail']->id); ?>,<?php echo e($data['card_detail']->card_id); ?>)"><i class="fa fa-trash"></i></button>
</div>
<div class="col-sm-12 divs-data" style="display:none" id="div-<?php echo e($data['card_detail']->id); ?>">
    <br class="br-<?php echo e($data['card_detail']->id); ?>">
    <?php echo $__env->make('Cards.itemsUpdate.TypeForms.form'.$data['item']->id,['data' => $data['card_detail']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<br class=""><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/addItem.blade.php ENDPATH**/ ?>