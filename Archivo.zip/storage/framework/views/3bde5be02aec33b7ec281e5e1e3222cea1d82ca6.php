
<?php if($card_style['background_color']): ?>
<div class="mobile-screen scroll" id="mobil-vition" style=" background-color:<?php echo e($data['background_image_color']); ?>;">
<?php else: ?>
    <div class="mobile-screen scroll" id="mobil-vition" style="background-image: url(<?php echo e($actual_bg); ?>) ">
<?php endif; ?>
    <div class="col-sm-12 mx-auto d-block ">
        <?php $__currentLoopData = $cardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
            <div class="col-sm-12" id="div-<?php echo e($ci['card_detail']->id); ?>">
                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$ci['item']->id, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/keypl.blade.php ENDPATH**/ ?>