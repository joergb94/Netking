<div class="row justify-content-between">
    <div class="card col-sm-7" id="FormModal">
        <div class="col-sm-12">
          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Create Keypl</h4>
            <button type="button" class="close" onclick="Cards.close()">&times;</button>
          </div>
  
          <!-- Modal body -->
          <div class="modal-body">
            <form id="card-form">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home">Principal Data</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu1">Networks Data</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu2">Details Data</a>
                  </li>
                </ul>
  
                <!-- Tab panes -->
                <div class="tab-content">
                  <div id="home" class="container tab-pane active"><br>
                    <?php echo $__env->make('Cards.itemsCreate.cardForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div id="menu1" class="container tab-pane fade"><br>
                    <?php echo $__env->make('Cards.itemsCreate.networkForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div id="menu2" class="container tab-pane fade"><br>
                    <h3>Details Data</h3>
                  </div>
                </div>
            </form>
          </div>
  
          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="button" class="btn btn-success btn-save" onclick="Cards.prev()">Preview <i
              class='fas fa-plus'></i></button>
            <button type="button" class="btn btn-success btn-save" onclick="Cards.save('update',<?php echo e($data['id']); ?>)">Update <i
                class='fas fa-plus'></i></button>
            <button type="button" class="btn btn-danger" onclick="Cards.close()" >Cancel <i
                class='fas fa-window-close'></i></button>
          </div>
  
        </div>
    </div>
    <div class="col-sm-4 all-screen">
           <div class="card device-case">
              <div class="mobile-screen" id="mobil-vition" style="background-image: url(<?php echo e($actual_bg); ?>)">
              <?php echo $__env->make('Cards.keypl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
           </div>
    </div>
  </div>
  <?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/edit.blade.php ENDPATH**/ ?>