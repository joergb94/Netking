<div class="row justify-content-between">
    <div class="col-12">
        <a class="btn btn-primary btn-block <?php echo e($btn_shape); ?>" target="_blank" href="<?php echo e($ci['card_detail']['description']); ?>" >
            <h3 style="font-family:<?php echo e($text_font->name); ?>;"><?php echo e($ci['card_detail']['name']); ?></h3>
        </a>
    </div>
   
</div>
<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div10.blade.php ENDPATH**/ ?>