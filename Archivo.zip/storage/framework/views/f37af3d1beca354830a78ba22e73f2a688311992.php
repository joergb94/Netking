<div class="row justify-content-between">
    <div class="col-12">
        <iframe class="btn-rounded"
                src="https://open.spotify.com/embed/playlist/<?php echo e($ci['card_detail']['name']); ?>?utm_source=generator" 
                width="100%" 
                height="380" 
                frameBorder="0" 
                allowfullscreen="" 
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture">
        </iframe>
    </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div7.blade.php ENDPATH**/ ?>