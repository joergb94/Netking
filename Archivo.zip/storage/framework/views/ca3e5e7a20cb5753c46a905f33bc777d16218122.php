<div class="col-sm-12" id='data-card'>
    <div class="col-sm-12">
        <div class="form-group">
            <label>About me</label>
            <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" class="form-control" name="phone" id="phone">
        </div>
        <div class="form-group">
            <label>Cell Phone</label>
            <input type="text" class="form-control" name="cellphone" id="cellphone">
        </div>
        <div class="form-group">
            <label>Business</label>
            <input type="text" class="form-control" name="business" id="business">
        </div>
        <div class="form-group">
            <label>Scholarship</label>
            <input type="text" class="form-control" name="scholarship" id="scholarship">
        </div>
        <div class="form-group">
            <label>Itroductive video</label>
            <input type="file" class="form-control" name="video" id="video">
        </div>
    </div>
    </div>
<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsCreate/detailForm.blade.php ENDPATH**/ ?>