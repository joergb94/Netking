<div class="row justify-content-between">
    <div class="card col-sm-12 col-md-12 col-lg-7 col-xl-7" id="FormModal">
        <div class="col-sm-12">
          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Edit Keypl</h4>
            <button type="button" class="close" onclick="Cards.close()">&times;</button>
          </div>
   
          <!-- Modal body -->
          <div class="modal-body">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#General">General</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#styleK">Style</a>
                  </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content scroll">
                  <div id="General" class="container tab-pane active">
                      <div class="col-sm-12" id="contenedor-divs">
                          <br>
                          <?php $__currentLoopData = $cardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="btn-group col-sm-12" id="btn-group-<?php echo e($ci['card_detail']->id); ?>">
                                  <button type="button" class="btn <?php echo e($ci['item']->style); ?> btn-block"   onclick="transactions.toggle(<?php echo e($ci['card_detail']->id); ?>)" >
                                    <h2><?php echo e($ci['item']->name); ?> <i class="<?php echo e($ci['item']->icon); ?>"></i></h2>
                                 </button>
                                <button type="button" class="btn <?php echo e($ci['item']->style); ?> delete" id="btn-delete-<?php echo e($ci['card_detail']->id); ?>" style="display:none"  onclick="Cards.delete_item(<?php echo e($ci['card_detail']->id); ?>,<?php echo e($data['id']); ?>)"><i class="fa fa-trash"></i></button>
                              </div>
                              <div class="col-sm-12 divs-data" style="display:none" id="div-<?php echo e($ci['card_detail']->id); ?>">
                              <br class="br-">
                              <?php echo $__env->make('Cards.itemsUpdate.TypeForms.form'.$ci['item']->id,['data' => $ci['card_detail']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <br class="br-<?php echo e($ci['card_detail']->id); ?>">
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                     <button type="button" class="btn btn-light btn-block"    onclick="Cards.modal_item(<?php echo e($data['id']); ?>)"><h2>Agregar Bloque <i class="fa fa-plus"></i></h2></button>
                  </div>
                  <div id="styleK" class="container tab-pane fade"><br>
                        <?php echo $__env->make('Cards.itemsUpdate.cardForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
          </div>
  
          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="button" class="btn btn-success btn-save" onclick="Cards.save('update',<?php echo e($data['id']); ?>)">Update <i
                class='fas fa-plus'></i></button>
            <button type="button" class="btn btn-danger" onclick="Cards.close()" >Cancel <i
                class='fas fa-window-close'></i></button>
          </div>
  
        </div>
    </div>
    <div class="col-sm-4 all-screen mx-auto d-block sticky">
           <div class="card device-case">
              <?php echo $__env->make('Cards.itemsUpdate.keypl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="mobile-screen-loadig bg-warning" id="loading-mobil-vition" style="display:none">
                  <div class="container text-center">
                    <br><br>
                    <div class="spinner-grow text-dark"></div>
                    <div class="spinner-grow text-dark"></div>
                    <div class="spinner-grow text-dark"></div>
                  </div>
              </div>
           </div>
    </div>
</div>
<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/edit.blade.php ENDPATH**/ ?>