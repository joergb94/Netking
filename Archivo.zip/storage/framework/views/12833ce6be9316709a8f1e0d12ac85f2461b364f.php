<div class="row justify-content-between">
    <div class="col-12 <?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?>">
        <?php echo $ci['card_detail']['description']; ?>

    </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div4.blade.php ENDPATH**/ ?>