<div class="row justify-content-between">
                <div class="col-12 text-center mx-auto d-block" id="social">
                    <?php if(isset($data['card_network'])): ?>
                        <?php $__currentLoopData = $data['card_network']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn <?php echo e($btn_shape); ?> btn-social-icon <?php echo e($item['social_network']['btn_network']); ?>" target="_blank" href="<?php echo e($item['url']); ?>">
                            <span class="<?php echo e($item['social_network']['icon']); ?>"></span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsUpdate/itemsKeypl/div2.blade.php ENDPATH**/ ?>