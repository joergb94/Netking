<div class="sidebar">
			
			<div class="sidebar-background"></div>
			<div class="sidebar-wrapper scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="avatar-sm float-left mr-2">
							<img src="<?php echo e((Auth::user()->image)?Auth::user()->path.Auth::user()->image:"https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"); ?>" alt="..." class="avatar-img rounded-circle">
						</div>
						<div class="info">
							<a>
								<span>
									<?php echo e(Auth::user()->name); ?>

									<span class="user-level"><?php echo e(Auth::user()->email); ?></span>
									
								</span>
							</a>
							<div class="clearfix"></div>
						</div>
					</div>
					<ul class="nav">
						<?php $__empty_1 = true; $__currentLoopData = $dm['data_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<?php if($menu->id == 4): ?>
						
						<?php else: ?>
						<li id="menu<?php echo e($menu->id); ?>" class="nav-item">
							<a href="<?php echo e($menu->link); ?>" class="nav-link">
								<i style="color:red;"
									class="<?php echo e($menu->icon); ?>"></i><?php echo e($menu->name); ?></a>
						</li>
						<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="nav-item active">
                        Sin Accessos
                    </li>
                <?php endif; ?>
						
					</ul>
				</div>
			</div>
		</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/layouts/items/sidebar.blade.php ENDPATH**/ ?>