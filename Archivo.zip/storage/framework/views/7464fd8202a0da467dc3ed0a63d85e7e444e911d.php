
<div class="row justify-content-between">
  <div class="card col-sm-7" id="FormModal">
      <div class="col-sm-12">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Create Keypl</h4>
          <button type="button" class="close" onclick="Cards.close()">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#General">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#styleK">Menu 1</a>
                  </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                  <div id="General" class="container tab-pane active"><br>
                      <?php $__currentLoopData = $cardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn btn-primary btn-block"   onclick="$('#div-<?php echo e($ci->id); ?>').slideToggle('slow');" ><?php echo e($ci->name); ?></button>
                          <div class="col-sm-12" style="display:none" id="div-<?php echo e($ci->id); ?>">
                          <br>
                          <?php echo $__env->make('Cards.itemsUpdate.TypeForms.form'.$ci->id,['data' => $ci], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div id="styleK" class="container tab-pane fade"><br>
                        <?php echo $__env->make('Cards.itemsCreate.cardForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
          
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-success btn-save" onclick="Cards.prev()">Preview <i
            class='fas fa-plus'></i></button>
          <button type="button" class="btn btn-success btn-save" onclick="Cards.save('add')">Create <i
              class='fas fa-plus'></i></button>
          <button type="button" class="btn btn-danger" onclick="Cards.close()" >Cancel <i
              class='fas fa-window-close'></i></button>
        </div>

      </div>
  </div>
  <div class="col-sm-4 all-screen">
         <div class="card device-case">
            <div class="mobile-screen" id="mobil-vition">
            <?php echo $__env->make('Cards.itemsCreate.keypl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
         </div>
  </div>
</div>
<?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/create.blade.php ENDPATH**/ ?>