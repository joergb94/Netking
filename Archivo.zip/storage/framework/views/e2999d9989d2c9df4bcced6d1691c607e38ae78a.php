<div class="col-sm-12">
    <br>
    <div class="col-sm-12">
        <div class="row justify-content-between">
            <div class="col-sm-12 text-center" id="contend-image">
                <img src="https://www.w3schools.com/bootstrap4/cinqueterre.jpg" class="rounded" alt="Cinque Terre" width="100px" height="100px" id="imageProfile"> 
            </div>
            <div class="col-sm-12 text-center" id="contend-title">
                <br>
                <div class="col-sm-12" id='content-title'>
                        <h2 class="text-color" id="titlephone"></h2>
                </div>
                    <p class="text-color" id="namephone"><?php echo e($user['name']); ?></p>
             
                
                <h6 class="text-color" id="subephone"></h6>
            </div>
           
        </div>
    </div>
    <br>
    <div class="row justify-content-between">
        <div class="col-sm-12 text-center" id="social">
        </div>
    </div>
</div><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsCreate/keypl.blade.php ENDPATH**/ ?>