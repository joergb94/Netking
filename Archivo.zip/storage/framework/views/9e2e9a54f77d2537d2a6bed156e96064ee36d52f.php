 <div class="col-sm-12" id='data-card'>
          <div class="form-group">
            <label>Image Profile:</label>
              <div class="input-group mb-3">
                <input type="file" class="form-control" id="image" name="image">
                <div class="input-group-append">
                  <select class="form-control max-height" id="shape_image"  onchange="Cards.prev()" name="shape_image">
                    <option value="0">Square</option>
                    <option value="1" >Rounded</option>
                  </select>
                </div>
                 
            </div> 
          </div>
          <div class="form-group">
            <label>Title:</label>
            <input type="text" onchange="Cards.prev()" id="title" name="title" value="<?php if(isset($data['title'])): ?><?php echo e($data['title']); ?><?php endif; ?>" class="form-control">
          </div>
          <div class="form-group">
            <label>Subtitle:</label>
            <input type="text" onchange="Cards.prev()" id="subtitle" name="subtitle" value="<?php if(isset($data['subtitle'])): ?><?php echo e($data['subtitle']); ?><?php endif; ?>" class="form-control">
          </div>
          <div class="form-group">
            <label>Orientation:</label>
            <select class="form-control" id="head_orientation"  onchange="Cards.prev()" name="head_orientation">
                    <?php if(isset($card_style)): ?>
                    <?php if($card_style->head_orientation == 1): ?>
                    <option value="0">Vertical</option>
                    <option value="1" selected>Horizontal</option>
                    <?php else: ?>
                    <option value="0" selected>Vertical</option>
                    <option value="1" >Horizontal</option>
                    <?php endif; ?>
                    <?php else: ?>
                    <option value="0" >Vertical</option>
                    <option value="1" >Horizontal</option>
                    <?php endif; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Theme:</label>
            <input type="text" onchange="Cards.prev()" id="theme" name="theme" value="" class="form-control">
          </div>
          <div class="form-group">
            <label>Backgroud:</label>
            <select name="background" id="background" onchange="Cards.prev()" class="form-control">
              <?php $__empty_1 = true; $__currentLoopData = $backgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php if(isset($data['background_image_id'])): ?>
                      <?php if($item['id'] == $data['background_image_id']): ?>
                      <option value="<?php echo e($item['id']); ?>" selected><?php echo e($item['name']); ?></option>
                      <?php else: ?>
                      <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                      <?php endif; ?>
                  <?php else: ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <option value="">No data</option> 
              <?php endif; ?>
            </select>
          </div>
          <div class="form-group">
          <label>Backgroud:</label>
            <div class="custom-control custom-checkbox">
                <select  id="largeTitle" onchange="Cards.prev()" name="large_text" class="form-control">
                  <?php if(isset($data)): ?>
                    <?php if($data['large_text'] == 1): ?>
                    <option value="0">Medium</option>
                    <option value="1" selected>Big</option>
                    <?php else: ?>
                    <option value="0" selected>Medium</option>
                    <option value="1">Big</option>
                    <?php endif; ?>
                    <?php else: ?>
                    <option value="0" selected>Medium</option>
                    <option value="1">Big</option>
                    <?php endif; ?>
                  
                </select>
            </div>
          </div>
          <div class="form-group">
            <label>Color Text:</label>
            <input onchange="Cards.prev()"  type="text" id="colorInput" name='color' data-jscolor="" class="form-control" value="<?php echo e((isset($data['color']))?$data['color']:''); ?>">
          </div>
          <div class="form-group">
            <select onchange="Cards.prev()" name="text_style" id="text_style" class="form-control">
              <?php $__empty_1 = true; $__currentLoopData = $text_styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text_style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <option value="<?php echo e($text_style['id']); ?>"><?php echo e($text_style['name']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <option value="">No style</option>
              <?php endif; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Location:</label>
            <input type="text" id="ocation" onchange="Cards.prev()" name="location" value="<?php echo e((isset($data['location']))?$data['location']:''); ?>" class="form-control">
          </div>
 </div>       
<script>
    var myPicker = new JSColor('#colorInput', {format:'hex'});
</script><?php /**PATH /Users/jorgeandrespuertoloeza/Documents/Trabajo/Netking/resources/views/Cards/itemsCreate/cardForm.blade.php ENDPATH**/ ?>