<div class="modal fade" id="FormModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
  
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
  
        <!-- Modal body -->
        <div class="modal-body">
          <div class="row">
          <?php $__empty_1 = true; $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php if($membership->id != 2): ?>
          <div class="col-sm-4">
            <div class="card">
              <div class="card-header">
                <?php echo e($membership->membership); ?>

              </div>
              <div class="card-body">
                <blockquote class="blockquote mb-0">
                  <p><?php echo $membership->description; ?></p>
                  <footer class="blockquote-footer">Cantidad de tarjetas: <?php echo e($membership->quantity); ?> </footer>
                </blockquote>
              </div>
              <div class="card-footer">
                  <?php if($membership->id == 2): ?>
                  <button type="button" class="btn btn-success" onclick="Profile.purchase_extra(<?php echo e($membership->id); ?>)">Comprar membresia <i
                      class='fas fa-window-close'></i></button>
                  <?php else: ?>
                  <button type="button" class="btn btn-success" onclick="Profile.purchase(<?php echo e($membership->id); ?>)">Comprar membresia <i
                      class='fas fa-window-close'></i></button>
                  <?php endif; ?>
                </div>
            </div>
            </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              
          <?php endif; ?>
        </div>
        </div>
  
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel <i
              class='fas fa-window-close'></i></button>
        </div>
  
      </div>
    </div>
  </div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Profile/membershipModal.blade.php ENDPATH**/ ?>