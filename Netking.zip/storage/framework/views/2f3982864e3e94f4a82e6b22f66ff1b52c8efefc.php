<div id="styleMore" class="tab-pane fade col-12">
<div class="modal-header">
          <h4 class="modal-title">Youtube Video Presentation </h4>
          <?php echo $__env->make('Cards.itemsUpdate.itemsForm.buttonDevice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
          <div class="form-group" style="display:none">
            <label>Theme:</label>
            <select  id="theme" name="theme" onchange="Cards.save_asinc_theme(<?php echo e($data['id']); ?>)" class="form-control">
              <?php $__empty_1 = true; $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php if(isset($data['themes_id'])): ?>
                      <?php if($theme['id'] == $data['themes_id']): ?>
                      <option value="<?php echo e($theme['id']); ?>" selected><?php echo e($theme['name']); ?></option>
                      <?php else: ?>
                      <option value="<?php echo e($theme['id']); ?>"><?php echo e($theme['name']); ?></option>
                      <?php endif; ?>
                  <?php else: ?>
                  <option value="<?php echo e($theme['id']); ?>"><?php echo e($theme['name']); ?></option>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <option value="">No data</option> 
              <?php endif; ?>
            </select>
          </div>
          <div class="form-group" style="display:none">
            <label>Backgroud:</label>
            <select name="background" id="background" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" class="form-control">
              <?php $__empty_1 = true; $__currentLoopData = $backgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php if(isset($data['background_image_id'])): ?>
                      <?php if($item['id'] == $data['background_image_id']): ?>
                      <option value="<?php echo e($item['id']); ?>" selected><?php echo e($item['name']); ?></option>
                      <?php else: ?>
                      <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                      <?php endif; ?>
                  <?php else: ?>
                  <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <option value="">No data</option> 
              <?php endif; ?>
            </select>
          </div>
          <div class="form-group" style="display:none">
            <label>Location:</label>
            <input type="text" id="ocation" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="location" value="<?php echo e((isset($data['location']))?$data['location']:''); ?>" class="form-control">
          </div>
          <div class="form-group">
            <label>Youtube link:</label>
          
            <input type="text" id="description<?php echo e($presentation['id']); ?>" onchange="Cards.save_item(<?php echo e($presentation['id']); ?>,3)" name="location" value="<?php echo e($presentation['description']); ?>" class="form-control">
          </div>
</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsForm/moreStyle.blade.php ENDPATH**/ ?>