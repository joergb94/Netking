
       <div class="row justify-content-between">
                <?php $__currentLoopData = $cardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($ci['item'])): ?>
                    <?php if($ci['item']->id == 2): ?>

                        <div class="dashed col-12  theme4-padding" id="drop<?php echo e($ci['card_detail']->id); ?>" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                            <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($ci['card_detail']->id); ?>">
                                <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($ci['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($ci['card_detail']->id); ?>,<?php echo e($ci['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                    <?php if($ci['item']->id == 5): ?>
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$ci['item']->id,['ci' => $ci,'template'=>$ci['card_detail']['item_data'],'theme_shape'=>'theme4-shape4 mx-auto d-block'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php else: ?>
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$ci['item']->id,['ci' => $ci,'template'=>230,'theme_shape'=>'theme4-shape4 mx-auto d-block'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="dashed col-12 theme4-col-12 theme4-padding" id="drop<?php echo e($ci['card_detail']->id); ?>" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                            <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($ci['card_detail']->id); ?>">
                                <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($ci['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($ci['card_detail']->id); ?>,<?php echo e($ci['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                    <?php if($ci['item']->id == 5): ?>
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$ci['item']->id,['ci' => $ci,'template'=>$ci['card_detail']['item_data'],'theme_shape'=>'theme4-shape4 mx-auto d-block'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php else: ?>
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$ci['item']->id,['ci' => $ci,'template'=>230,'theme_shape'=>'theme4-shape4 mx-auto d-block'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="col-12  theme4 theme<?php echo e($data['themes_id']); ?>-padding btn-default-theme4" id="drop<?php echo e($ci['card_detail']->id); ?>"  >
                         <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $ci['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div> 
                <?php endif; ?>                   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/themes/theme4.blade.php ENDPATH**/ ?>