
  <div class="col-12 mx-auto d-block <?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?> theme<?php echo e($data['themes_id']); ?>-padding <?php echo e($theme_shape); ?>">
    <blockquote class="twitter-tweet ">
      <p lang="en" dir="ltr">twit</p>&mdash; keypls 
      <a href="<?php echo e($ci['card_detail']['description']); ?>?ref_src=twsrc%5Etfw">
      January 17, 2022</a>
      </blockquote>
      <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
  </div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/itemsKeypl/div6.blade.php ENDPATH**/ ?>