<style>
    ::-webkit-scrollbar 
    {
        width: 5px;
    }

    /* Handle */
   
   .keypls-body
    {
            <?php if($card_style['background_color'] == 1): ?>
                /* The color used */
                background-color: <?php echo $data["background_image_color"]; ?>;
             
            <?php else: ?>
                /* The image used */
                background-image: url('<?php echo e($actual_bg); ?>');
            <?php endif; ?>
            /* Full height */
            height: 100vh;
            width: 100%; 
            overflow-y: scroll;
            
            /* Center and scale the image nicely */
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;

            color: white;
            font-weight: bold;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 2;
            padding: 20px;
            text-align: center;
            }
    }
        .keypl-btn-social
        {
            color: <?php echo $data['color']; ?>;
        }
            
        .keypl-btn-social:hover 
        {
            background: <?php echo $data['color']; ?>;
            color: white;
        }

        .keypl-text-social
        {
            color: <?php echo $data['color']; ?>;
        }
            
        .keypl-text-social:hover 
        {
            color: white;
        }


          .keypl-btn 
        {
            border-color: <?php echo $data['color']; ?>;
            color: <?php echo $data['color']; ?>;
        }
            
        .keypl-btn:hover 
        {
            background: <?php echo $data['color']; ?>;
            color: white;
        }

        .keypl-btn-full 
        {
            background: <?php echo $data['color']; ?>;
            color: white;
        }
</style><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/stylek/css.blade.php ENDPATH**/ ?>