<div class="row padding-home">
						<div class="col-12">
							<?php echo $__env->make('home.items.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
						<div class="col-12">
							<?php echo $__env->make('home.items.content-keypls', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
		
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/home/Premium/content.blade.php ENDPATH**/ ?>