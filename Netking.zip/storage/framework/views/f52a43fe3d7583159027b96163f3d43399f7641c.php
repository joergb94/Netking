
<?php $__env->startSection('content'); ?>
<div class="col-12 bg-white">
    <a class="" href="/"><h1 class="text-color-keypl"><i class="fa fa-angle-left"></i></h1></a>
    <br>
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <img class="img-fluid" src="<?php echo e(asset('img/register.png')); ?>" alt="">
                        </div>
                        <div class="col-12 col-sm-6">
                        <h1>Bienvenidx a keypl</h1>
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group form-floating-label">

                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> input-border-bottom" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                    <label for="email" class="placeholder"><?php echo e(__('CORREO')); ?></label>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>

                            <div class="form-group form-floating-label">
                               
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> input-border-bottom" name="password" required autocomplete="new-password">
                                    <label for="password" class="placeholder"><?php echo e(__('CONTRASEÑA')); ?></label>

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>

                            <div class="form-group form-floating-label">
                                    <input id="password-confirm" type="password" class="form-control input-border-bottom" name="password_confirmation" required autocomplete="new-password">
                                    <label for="password-confirm" class="placeholder"><?php echo e(__('CONFIRMAR CONTRASEÑA')); ?></label>
                            </div>
                            <div class="form-group form-floating-label">
                                <div class="col-12">
                                    <div class="custom-control custom-checkbox col-8 text-flow">
                                        <input class="form-check-input custom-control-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    
                                        <label class="custom-control-label text-flow" for="remember">
                                            <h6 class="text-dark">HE LEIDO Y ACEPTO LOS TERMINOS Y</h6>  
                                            <h6 class="text-dark">CONDICIONES</h6>
                                           
                                        </label>
                                    </div>
                                    <a href="<?php echo e(route('facebook.login')); ?>" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i>
                                    Login with Facebook
                                    </a>
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-12 col-sm-6 col-md-6 offset-md-4 mx-auto d-block">
                                    <button type="submit" class="btn bg-keypl btn-block btn-rounded-keypls-start">
                                        <?php echo e(__('CREAR CUENTA')); ?>

                                    </button>
                                </div>
                                
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-12 col-sm-6 col-md-6 offset-md-4 mx-auto d-block text-center">
                                       YA TIENES CUENTA? <a class="text-color-keypl" href="/login"> INICIA SESION</a>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/auth/register.blade.php ENDPATH**/ ?>