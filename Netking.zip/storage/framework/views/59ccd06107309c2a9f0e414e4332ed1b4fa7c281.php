
<?php $__env->startSection('style'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/editkeypl.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-inner">
<div class="card" id="index_blade">
  <?php echo $__env->make('Cards.items.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="card-body">
    <!--row-->
    <?php echo $__env->make('Cards.items.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="loading" style="display:none" class="col-sm-12 text-center">
      </br></br></br>
      <div class="col-sm-12">
        <h2>Loading...</h2>
      </div>
      <div class="spinner-grow text-muted"></div>
      <div class="spinner-grow text-primary"></div>
      <div class="spinner-grow text-info"></div>
      <div class="spinner-grow text-danger"></div>
      <div class="spinner-grow text-secondary"></div>
      </br></br></br></br>
    </div>
  </div>
  <!--card-body-->
</div>
<!--card-->


<!-- show_blade -->
<div id="show_blade" style="display:none">
  <div id="card_show"></div>
</div>
</div>
<!-- Passing BASE URL to AJAX -->
<input id="url" type="hidden" value="<?php echo e(\Request::url()); ?>">
<input id="baseUrl" type="hidden" value="<?php echo e(\Request::root()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <div id="show_blade2" style="display:none">
      <div id="card_show2"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

  <script src="<?php echo e(asset('js/chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/actions/Cards.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/index.blade.php ENDPATH**/ ?>