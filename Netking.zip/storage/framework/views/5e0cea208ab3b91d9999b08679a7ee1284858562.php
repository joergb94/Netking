  <!-- The Modal -->
  <div id="addnew" class="tab-pane fade col-12">

      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Agregar Bloque</h4> 
          <?php echo $__env->make('Cards.itemsUpdate.itemsForm.buttonDevice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <div class="row justify-content-between">
                 <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4">
                        <br>
                        <button type="button" onclick="Cards.add_item('<?php echo e($item->id); ?>')" class="btn <?php echo e($item->style); ?> btn-div text-center ">
                            <h1><i class="<?php echo e($item->icon); ?>"></i></h1>
                            <h3><?php echo e($item->name); ?></h3>
                        </button>
                    </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <input type="hidden" id="keypls_id" value="0">
            </div>
        </div>
      </div>
    </div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsForm/addnew.blade.php ENDPATH**/ ?>