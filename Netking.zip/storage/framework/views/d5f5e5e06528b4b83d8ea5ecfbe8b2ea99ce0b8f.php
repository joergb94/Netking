
       <div class="row justify-content-between">

                <?php $__currentLoopData = $cardItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if(isset($ci['item'])): ?>
                   <?php if($ci['item']->id == 8 || $ci['item']->id == 10): ?>
                   <div class="col-12 theme4-col-10 theme4-padding" id="div-<?php echo e($ci['card_detail']->id); ?>">
                   <?php elseif($ci['item']->id == 2): ?>
                   <div class="col-12 theme4-padding" id="div-<?php echo e($ci['card_detail']->id); ?>">
                   <?php else: ?>
                   <div class="col-12 theme4-col-12 theme4-padding" id="div-<?php echo e($ci['card_detail']->id); ?>">
                   <?php endif; ?>
                    
                         <?php if($ci['item']->id == 5): ?>
                            <?php echo $__env->make('Keypls.itemsUpdate.itemsKeypl.div'.$ci['item']->id,['ci' => $ci,'template'=>$ci['card_detail']['item_data'],'theme_shape'=>'theme4-shape4 mx-auto d-block'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                        <?php echo $__env->make('Keypls.itemsUpdate.itemsKeypl.div'.$ci['item']->id,['ci' => $ci,'template'=>'100%','theme_shape'=>'theme4-shape4 mx-auto d-block'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
         
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/themes/theme4.blade.php ENDPATH**/ ?>