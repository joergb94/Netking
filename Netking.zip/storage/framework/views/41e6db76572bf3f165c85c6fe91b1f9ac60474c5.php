
<a  style="height:<?php echo e($template == 0?315:$template); ?>px;"
    value="<?php echo e($ci['card_detail']['id']); ?>" href="<?php echo e($ci['card_detail']['description']); ?>"  
    class="btn btn-full-screen-edit <?php echo e($card_style['button_style'] == 0? 'keypl-btn ':'keypl-btn-full'); ?> <?php echo e(!$btn_shape?'':'theme-'.$data['themes_id'].'-btn-rounded'); ?> btn-block" 
    download>
    <div class="col-12 centered-btn"   onmousedown="return false">
         <h3 class="d-none d-md-block d-lg-block d-xl-block <?php echo e($card_style['button_style'] == 0? 'keypl-text-social ':''); ?>" style="font-family:<?php echo e($text_font->name); ?>;"><?php echo e($ci['card_detail']['name']); ?> <i class="fa fa-file-download"></i></h3>
        <i class="fa fa-file-download d-block d-sm-block d-md-none d-lg-none d-xl-none <?php echo e($card_style['button_style'] == 0? 'keypl-text-social ':''); ?>"></i>
    </div>
</a>


<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsKeypl/div8.blade.php ENDPATH**/ ?>