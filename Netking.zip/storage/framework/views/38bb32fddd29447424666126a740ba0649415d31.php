
    <div class="row justify-content-between bg-white <?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?> theme<?php echo e($data['themes_id']); ?>-padding <?php echo e($theme_shape); ?>">
        <div class="col-12 "   onmousedown="return false">
            <?php echo $ci['card_detail']['description']; ?>

        </div>
    </div>

<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsKeypl/div4.blade.php ENDPATH**/ ?>