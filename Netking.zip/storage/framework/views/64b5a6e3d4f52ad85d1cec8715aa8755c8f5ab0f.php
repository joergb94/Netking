

    <?php if($card_style['background_color']): ?>
    <div class="mobile-screen" id="mobil-vition" style=" background-color:<?php echo e($data['background_image_color']); ?>;">
    <?php else: ?>
    <div class="mobile-screen" id="mobil-vition" style="background-image: url('<?php echo e($actual_bg); ?>') ">
    <?php endif; ?>
    <style>
           .keypl-btn-social
        {
            color: <?php echo $data['color']; ?>;
        }
            
        .keypl-btn-social:hover 
        {
            background: <?php echo $data['color']; ?>;
            color: white;
        }

          .keypl-btn 
        {
            border-color: <?php echo $data['color']; ?>;
            color: <?php echo $data['color']; ?>;
        }
            
        .keypl-btn:hover 
        {
            background: <?php echo $data['color']; ?>;
            color: white;
        }

        .keypl-btn-full 
        {
            background: <?php echo $data['color']; ?>;
            color: white;
        }
    </style>
        <div class="col-sm-12 mx-auto d-block ">
            <?php echo $__env->make('Cards.itemsUpdate.themes.theme'.$data['themes_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/keypl.blade.php ENDPATH**/ ?>