

<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="row justify-content-center" >
        <div class="col-12">
            <div class="">
                <div class="card-body ">
                    <div class="row ">
                        <div class="col-sm-6">
                                <img class="img-fluid image-welcome mx-auto d-block" src="<?php echo e(asset('img/welcome1.png')); ?>" >
                        </div>
                        <div class="col-sm-6">
                        <?php if(auth()->guard()->guest()): ?>
                                <div class="form-group row mb-0 padding-welcome-keypls">
                                    <div class="col-12 col-sm-6 col-md-6 offset-md-4 mx-auto d-block">
                                        <a href="<?php echo e(route('register')); ?>">
                                            <button type="button" class="btn bg-keypl btn-block btn-rounded-keypls-start">
                                                <?php echo e(__('CREAR UNA CUENTA')); ?>

                                            </button>
                                        </a>
                                    </div>
                                </div>
                                <div class="form-group row mb-0">
                                    <div class="col-12 col-sm-6 col-md-6 offset-md-4 mx-auto d-block">
                                       <h6>¿YA ERES USUARIO?</h6>
                                    </div>
                                </div>
                                <div class="form-group row mb-0">
                                    <div class="col-12 col-sm-6 col-md-6 offset-md-4 mx-auto d-block">
                                         <a href="<?php echo e(route('login')); ?>">
                                            <button type="button" class="btn bg-keypl-nav btn-block btn-rounded-keypls-start">
                                                <?php echo e(__('INICIA SESION')); ?>

                                            </button>
                                        </a>
                                    </div>
                                </div>
				        <?php else: ?>
						        <div class="form-group row mb-0 padding-welcome-keypls">
                                    <div class="col-12 col-sm-6 col-md-6 offset-md-4 mx-auto d-block">
                                        <a href="<?php echo e(app('router')->has('home') ? route('home') : url('/')); ?>">
                                            <button type="button" class="btn bg-keypl btn-block btn-rounded-keypls-start">
                                                <?php echo e(__('IR AL INICIO')); ?>

                                            </button>
                                        </a>
                                    </div>
                                </div>
					    <?php endif; ?>
                               
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/welcome.blade.php ENDPATH**/ ?>