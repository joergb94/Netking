<div class="modal fade" id="FormModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">QR Keypl-<?php echo e($data['title']); ?>-<?php echo e($user['nickname']); ?></h4>
        <button type="button" class="close btn btn-outline-danger" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
          <div class="row">
              <div class="col-sm-12">
                  <div id="qrcode" class="mx-auto d-block"></div>
              </div>
              <div class="col-sm-12">
                <br>
                  <button type="button" id="button_link"  class="btn btn-warning text-dark btn-block" onclick="QR.copy_link()" value="<?php echo e(\Request::root()); ?>/Keypls/qr/<?php echo e($data->id); ?>"><strong>Copiar </strong> <?php echo e(\Request::root()); ?>/Keypls/<?php echo e($data->id); ?> 
                      <i id="iconCopyB" class="fa fa-copy"></i> 
                      <i id="iconCopyA" style="display:none;" class="fa fa-clipboard-check text-white"></i>
                    </button>
                <br>
                <button type="button"  class="btn btn-gray text-white btn-block" onclick="QR.download(<?php echo e($data->id); ?>)" ><strong>Descargar</strong> QR 
                    <i id="iconDB" class="fa fa-file-download"></i>
                    <i  id="iconDA" style="display:none;" class="fa fa-file-download text-dark"></i>
                </button>
                <br>
              </div>
          </div>
      </div>

    </div>
  </div>
</div>
<script>
     QR.show(<?php echo e($data->id); ?>);  
</script><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/show.blade.php ENDPATH**/ ?>