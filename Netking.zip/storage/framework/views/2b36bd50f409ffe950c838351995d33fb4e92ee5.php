<style>
                  #facebookDiv<?php echo e($ci['card_detail']['id']); ?> {
                    border:none;
                    overflow:hidden;
                    height:auto;
                }
          
    </style>
 
        <div id ="facebookDiv<?php echo e($ci['card_detail']['id']); ?>" class="col-12 theme<?php echo e($data['themes_id']); ?>-padding <?php echo e($theme_shape); ?> <?php echo e($theme_shape); ?>">
            <iframe 
                onmousedown="return false"
                class="<?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?>"
                width="100%"
                height="100%"
                src="<?php echo e($ci['card_detail']['name']); ?>" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
        </div>
  
    <?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsKeypl/div5.blade.php ENDPATH**/ ?>