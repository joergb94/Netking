
<div class="col-12 theme<?php echo e($data['themes_id']); ?>-padding">
    
                    <?php if($data['themes_id'] == 3): ?>
                    <div class="theme3-col-12 theme3-float">
                        <div class="row no-margin">
                            <div class="col-sm-12"  id="contend-image">
                                <div class="col-12 text-center">
                                    <img src="<?php echo e((isset($ci['card_detail']['item_data']))? $ci['card_detail']['item_data']:asset('img/profile.jpg')); ?>" class="<?php echo e($theme_shape); ?> mx-auto d-block" alt="Cinque Terre" id="imageProfile"> 
                                </div>
                               
                            </div>
                            <div class="col-sm-12" id="contend-title">
                                <div class="col-12">
                                    <br>
                                    <div class="label-theme3 mx-auto d-block">
                                        <?php if($data['large_text']): ?>
                                            <h1 class="text-color mx-auto d-block" id="titlephone" style="color:<?php echo $data['color']; ?>; font-family:<?php echo e($text_font->name); ?>;">
                                            <?php if(isset($ci['card_detail']['name'])): ?><?php echo e($ci['card_detail']['name']); ?><?php endif; ?>
                                        </h1>
                                        <?php else: ?>
                                            <h2 class="text-color mx-auto d-block" id="titlephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php if(isset($ci['card_detail']['name'])): ?><?php echo e($ci['card_detail']['name']); ?><?php endif; ?></h2>
                                        <?php endif; ?>                          
                                        <h6 class="text-color mx-auto d-block" id="subephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php if(isset($ci['card_detail']['description'])): ?><?php echo e($ci['card_detail']['description']); ?><?php endif; ?></h6>
                                    </div>   
                                </div>      
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="row justify-content-between ">
                        <div class="<?php echo e(($card_style['head_orientation'] == 1)?'col-6':'col-12'); ?> text-center no-margin" id="contend-image">
                              <?php echo $__env->make('Keypls.itemsUpdate.themes.button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                             <img 
                                src="<?php echo e((isset($ci['card_detail']['item_data']))? $ci['card_detail']['item_data']:asset('img/profile.jpg')); ?>" 
                                class="<?php echo e($card_style['shape_image'] == 0?'rounded-circle':'rounded'); ?>" 
                                alt="Cinque Terre" 
                                width="150px" 
                                height="150px" 
                                style="padding-right: 10px;"
                                id="imageProfile"> 
                        </div>
                        <div class="<?php echo e(($card_style['head_orientation'] == 1)?'col-6':'col-12'); ?> text-center" id="contend-title">
                            <br>
                            <div class="col-12" id='content-title'>
                                <?php if($data['large_text']): ?>
                                        <h1 class="text-color" id="titlephone" style="color:<?php echo $data['color']; ?>; font-family:<?php echo e($text_font->name); ?>;">
                                            <?php if(isset($ci['card_detail']['name'])): ?><?php echo e($ci['card_detail']['name']); ?><?php endif; ?>
                                        </h1>
                                <?php else: ?>
                                    <h2 class="text-color" id="titlephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php if(isset($ci['card_detail']['name'])): ?><?php echo e($ci['card_detail']['name']); ?><?php endif; ?></h2>
                                <?php endif; ?> 
                            </div>    
                            <p class="text-color theme-<?php echo e($data['themes_id']); ?>-text-size" id="subephone" style="color:<?php echo $data['color']; ?>;font-family:<?php echo e($text_font->name); ?>;"><?php if(isset($ci['card_detail']['description'])): ?><?php echo e($ci['card_detail']['description']); ?><?php endif; ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
    
</div>

<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/itemsKeypl/div1.blade.php ENDPATH**/ ?>