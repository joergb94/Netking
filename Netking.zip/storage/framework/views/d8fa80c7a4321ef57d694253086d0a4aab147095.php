<div id="styleText" class="tab-pane fade col-12">
<div class="modal-header">
          <h4 class="modal-title">Text </h4>
          <?php echo $__env->make('Cards.itemsUpdate.itemsForm.buttonDevice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="form-group">
     
                  <label>Color Text:</label>
                  <input onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)"  type="text" id="colorInput" name='color' data-jscolor="" class="form-control" value="<?php echo e((isset($data['color']))?$data['color']:''); ?>">
          </div>
          <div class="form-group">
            <div class="row">
              <div class="col-sm-6">
                <label>Size Text Header:</label>
                <div class="custom-control custom-checkbox">
                    <select  id="largeTitle" onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="large_text" class="form-control">
                      <?php if(isset($data)): ?>
                        <?php if($data['large_text'] == 1): ?>
                        <option value="0">Medium</option>
                        <option value="1" selected>Big</option>
                        <?php else: ?>
                        <option value="0" selected>Medium</option>
                        <option value="1">Big</option>
                        <?php endif; ?>
                        <?php else: ?>
                        <option value="0" selected>Medium</option>
                        <option value="1">Big</option>
                        <?php endif; ?>
                      
                    </select>
                </div>
              </div>
              <div class="col-sm-6">
                <label>Text Style:</label>
                <select onchange="Cards.save_asinc(<?php echo e($data['id']); ?>)" name="text_style_id" id="text_style" class="form-control">
                  <?php $__empty_1 = true; $__currentLoopData = $text_styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text_style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($text_style['id']); ?>"><?php echo e($text_style['name']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <option value="">No style</option>
                  <?php endif; ?>
                </select>
              </div>
            </div>
          </div>
</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsForm/textStyle.blade.php ENDPATH**/ ?>