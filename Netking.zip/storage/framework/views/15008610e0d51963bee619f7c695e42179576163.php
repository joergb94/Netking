<div class="col-12">
  <div class="card-header">
  <button type="button" class="btn btn-link" onclick="Cards.back_principal()"> <h4 class="text-dark"> <i class="fas fa-angle-left"></i> Link</h4></button>
</div>
  <div class="card-body">
    <form id="contact-form">
    <div class="form-group">
            <label for="email">Titulo:</label>
            <input type="text" class="form-control" placeholder="Enter title" value="<?php echo e($data->name); ?>" id="name<?php echo e($data->id); ?>">
        </div>
        <div class="form-group">
            <label for="email">Link:</label>
            <input type="text" class="form-control" placeholder="Enter link" value="<?php echo e($data->description); ?>" id="description<?php echo e($data->id); ?>">
        </div>
        <div class="form-group text-center">
            <button type="button" class="btn btn-primary" onclick="Cards.save_item(<?php echo e($data->id); ?>,<?php echo e($data->card_item_id); ?>)">Guardar</button>
        </div>
    </form>
  </div>
</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/TypeForms/form10.blade.php ENDPATH**/ ?>