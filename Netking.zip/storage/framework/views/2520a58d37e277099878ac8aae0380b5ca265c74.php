
<button class="btn btn-secondary btn-circle top-right-btn" data-toggle="tooltip"title="Editar Keypl!"   value="<?php echo e($friend?1:0); ?>" id="btn-follow">
    <?php if($friend == true): ?> 
        <span ><i class="fas fa-user-check"></i></span>
    <?php else: ?>
        <span ><i class="fas fa-user-plus"></i></span>
    <?php endif; ?>
</button><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/themes/button.blade.php ENDPATH**/ ?>