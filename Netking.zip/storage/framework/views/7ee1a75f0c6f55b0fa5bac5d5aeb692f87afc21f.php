<div class="col-12">
  <div class="card-header">
  <button type="button" class="btn btn-link" onclick="Cards.back_principal()"> <h4 class="text-dark"> <i class="fas fa-angle-left"></i> Agregar Publicacion de Facebook</h4></button>
   </div>
  <div class="card-body">
    <form id="facebook-form">
        <div class="form-group" style="display:none">
            <label for="email">Titulo:</label>
            <input type="email" class="form-control" placeholder="Enter email" value="<?php echo e($data->name); ?>" id="name<?php echo e($data->id); ?>">
        </div>
        <div class="form-group">
            <label for="newF">codigo de Facebook:</label>
            <textarea class="form-control" rows="5" id="description<?php echo e($data->id); ?>" onchange="$('#datasrc<?php echo e($data->id); ?>').html($('#description<?php echo e($data->id); ?>').val())"><?php echo e($data->description); ?></textarea>
            <div class="col-sm-12" style="display:none" id="datasrc<?php echo e($data->id); ?>"></div>
        </div>
        <div class="form-group text-center">
            <button type="button" class="btn btn-primary" onclick="Cards.save_item(<?php echo e($data->id); ?>,<?php echo e($data->card_item_id); ?>)">Guardar</button>
        </div>
    </form>
  </div>
</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/TypeForms/form5.blade.php ENDPATH**/ ?>