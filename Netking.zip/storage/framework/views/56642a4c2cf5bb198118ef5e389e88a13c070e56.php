
    <div class="col-12 theme<?php echo e($data['themes_id']); ?>-padding text-center mx-auto d-block">
        <a class="btn <?php echo e($card_style['button_style'] == 0? 'keypl-btn':'keypl-btn-full'); ?> btn-block <?php echo e($btn_shape); ?>" target="_blank" href="<?php echo e($ci['card_detail']['description']); ?>" >
            <h3 style="font-family:<?php echo e($text_font->name); ?>;"><?php echo $ci['card_detail']['name']; ?></h3>
        </a>
    </div>
   

<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/itemsKeypl/div11.blade.php ENDPATH**/ ?>