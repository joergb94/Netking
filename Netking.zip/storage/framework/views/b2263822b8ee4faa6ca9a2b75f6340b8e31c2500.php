
<?php $__env->startSection('style'); ?>
 <style>
   .canvas {
      border: 1px dotted #FFBF2F;
    }

    .chart-container {
      position: relative;
      margin: auto;
      height: 25vh;
      width: 80vw;
    }
 </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-inner">
<!--card-->
<?php echo $__env->make('home.'.$dm['type_membership']['membership'].'.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- show_blade -->
    <div id="show_blade" style="display:none">
    <div id="card_show"></div>
    </div>
</div>
<!-- Passing BASE URL to AJAX -->
<input id="url" type="hidden" value="<?php echo e(\Request::url()); ?>">
<input id="baseUrl" type="hidden" value="<?php echo e(\Request::root()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <div id="show_blade2" style="display:none">
      <div id="card_show2"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js" integrity="sha512-QSkVNOCYLtj73J4hbmVoOV6KVZuMluZlioC+trLpewV8qMjsWqlIQvkn1KGX2StWvPMdWGBqim1xlC8krl1EKQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="<?php echo e(asset('js/actions/Home.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/home/index.blade.php ENDPATH**/ ?>