
<iframe class="theme<?php echo e($data['themes_id']); ?>-shape <?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?> <?php echo e($template == 0?'':$template); ?> <?php echo e($theme_shape); ?>"
        src="https://open.spotify.com/embed/playlist/<?php echo e($ci['card_detail']['name']); ?>?utm_source=generator" 
        width="100%" 
        height="<?php echo e($template == 0?315:$template); ?>"
        frameBorder="0" 
        allowfullscreen="" 
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture">
</iframe>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/itemsKeypl/div7.blade.php ENDPATH**/ ?>