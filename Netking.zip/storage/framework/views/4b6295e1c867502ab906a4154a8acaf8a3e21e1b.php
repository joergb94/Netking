
	<nav class="navbar navbar-expand-sm fixed-bottom bg-keypl-nav nav-keypls-01" data-background-color="purple">
	
	

		
		<ul class="list-group list-group-horizontal ml-md-auto align-items-center">
				<?php if(auth()->guard()->guest()): ?>
						<?php if(Route::has('login')): ?>
							<li class="nav-link-keypls profile-pic">
								<a class="nav-link-keypls profile-pic" aria-expanded="false" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?> </a>
							</li>
						<?php endif; ?>
						<?php if(Route::has('register')): ?>
							<li class="nav-link-keypls profile-pic">
								<a class="nav-link-keypls profile-pic" aria-expanded="false"  href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
							</li>
						<?php endif; ?>
		
				<?php else: ?>
						<?php $__empty_1 = true; $__currentLoopData = $dm['data_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						
							<li id="menu<?php echo e($menu->id); ?>" class="nav-link-keypls profile-pic">
								<a href="<?php echo e($menu->link); ?>" class="nav-link-keypls nav-jeypls">
									<i style="color:red;"
										class="<?php echo e($menu->icon); ?>"></i><?php echo e($menu->name); ?></a>
							</li>
					
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<li class="nav-item active">
								Sin Accessos
							</li>
						<?php endif; ?>
					<?php endif; ?>
					</ul>
	
	</nav>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/layouts/items/main-header.blade.php ENDPATH**/ ?>