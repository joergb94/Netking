
							<div class="col-12 keypls-home" id="index_table">
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $data['keypls']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-6 col-sm-4">
                                            <a  href="/Keypls/<?php echo e($Card['id']); ?>" target="_blank" rel="noopener noreferrer">
                                            <div class=" div-rounded"  id="Card<?php echo e($Card->id); ?>">
                                                <div class="card-body text-center container-btn keypls-card">
                                                
                                                <?php if($Card->card_styles[0]->background_color): ?>
                                                        <div class="keypl-background mx-auto d-block div-rounded"  style="background-color:<?php echo e($Card['background_image_color']); ?>; color:<?php echo e($Card->color); ?>;">
                                                    <?php else: ?>
                                                        <div class="keypl-background mx-auto d-block div-rounded"  style="background-image: url('<?php echo e($Card->img_path); ?><?php echo e($Card->img_name); ?>'); color:<?php echo e($Card->color); ?>; background-size:cover; background-repeat:no-repeat;" >
                                                    <?php endif; ?>

                                                        <img class="keypl-img rounded-circle" src="<?php echo e((isset($Card->img))? $Card->img:asset('img/profile.jpg')); ?>" alt="<?php echo e($Card->title); ?>">
                                                    </div> 

                                                    <div class="mx-auto d-block keypl-title">
                                                        <h4><?php echo e($Card->title); ?></h4>
                                                    </div>
                                                    
                                                </div> 
                                            </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="col-12 text-center">
                                                <img class="keypl-img-not-found mx-auto d-block" src="<?php echo e(asset('img/nofound.png')); ?>">
                                                <h1>Oops!</h1>
                                                <h2>We can't find the keypl you're looking for.</h2>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <!--pagination section-->
                                    <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-7">
                                        <div class="float-left">
                                            <?php echo $data['keypls']->total(); ?> <?php echo e(trans_choice('Keypl|Keypls', $data['keypls']->total())); ?>

                                        </div>
                                        </div>
                                        <!--col-->
                                        <div class="col-5">
                                        <div class="float-right">
                                            <br>
                                            <?php echo $data['keypls']->render(); ?>

                                            <br>
                                        </div>
                                        </div>
                                        <!--col-->
                                    </div>
                                    <!--row-->
                                    </div>
							</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/home/items/content-keypls.blade.php ENDPATH**/ ?>