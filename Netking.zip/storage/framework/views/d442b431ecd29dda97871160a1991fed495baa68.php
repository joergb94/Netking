<div id="index_table">
  <div class="row">
    <!--table section-->
    <div class="col">
      <div class="col-sm-12">
            <div class="row">
              <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-6 col-sm-4">
                  <div class="card"  id="Card<?php echo e($Card->id); ?>">
                  <div class="card-body text-center container-btn keypls-card">
                                    
                                    <?php if($Card->card_styles[0]->background_color): ?>
                                        <div class="keypl-background mx-auto d-block div-rounded"  style="background-color:<?php echo e($Card['background_image_color']); ?>; color:<?php echo e($Card->color); ?>;">
                                        <?php else: ?>
                                        <div class="keypl-background mx-auto d-block div-rounded"  style="background-image: url('<?php echo e($Card->img_path); ?><?php echo e($Card->img_name); ?>'); color:<?php echo e($Card->color); ?>; background-size:cover; background-repeat:no-repeat;" >
                                        <?php endif; ?>
                                        <button class="btn btn-warning btn-show-<?php echo e($Card['id']); ?> btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit(<?php echo e($Card['id']); ?>)"><i class='fas fa-edit'></i></button>
                                        <button type="button" class="btn btn-danger btn-circle top-right btn-delete" style="display:none" onclick="Cards.delete(<?php echo e($Card['id']); ?>)" > <i class="fa fa-trash"></i></button>
                                            <img class="keypl-img rounded-circle" src="<?php echo e((isset($Card->img))? $Card->img:asset('img/profile.jpg')); ?>" alt="<?php echo e($Card->title); ?>">
                                        </div> 

                                        <div class="mx-auto d-block keypl-title">
                                            <h4><?php echo e($Card->title); ?></h4>
                                            <p class="text-keypl mx-auto d-block"><?php echo e($Card->subtitle); ?></p>
                                        </div>
                                        
                                    </div> 
                    <div class="card-footer text-center footer-keypl btn-update">
                        <?php echo $__env->make('Cards.items.buttons', ['Card' => $Card], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="col-6 col-sm-4 text-center">
                  <img class="keypl-img-not-found-2 mx-auto d-block" src="<?php echo e(asset('img/nofound.png')); ?>">
                  <h1>Oops!</h1>
                  <h2>We can't find the keypl you're looking for.</h2>
              </div>
              <?php endif; ?>
                <div class="col-6 col-sm-4">
                  <div class="card">
                          <button  class="btn btn-light keypls-card  btn-block" onclick="Cards.create()" >
                            <h1><i class="fa fa-plus"></i></h1>
                            <h3>Add new keypl</h3>
                          </button>
                  </div>
              </div>
            </div>
      </div>
    </div>
    <!--pagination section-->
    <div class="col-sm-12">
      <div class="row">
        <div class="col-7">
          <div class="float-left">
            <?php echo $data->total(); ?> <?php echo e(trans_choice('Keypl|Keypls', $data->total())); ?>

          </div>
        </div>
        <!--col-->
        <div class="col-5">
          <div class="float-right">
            <?php echo $data->render(); ?>

          </div>
        </div>
        <!--col-->
      </div>
      <!--row-->
    </div>
  </div>
</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/items/table.blade.php ENDPATH**/ ?>