
<div class="row justify-content-between">
  <div class="card col-sm-12" id="FormModal">
     
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Create Keypl</h4>
          <button type="button" class="btn btn-danger btn-circle top-right" onclick="Cards.close()" >
            <i class='fas fa-window-close'></i>
          </button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-12">
            <div class="row justify-content-center">
                <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($theme->id != 3): ?>
                    <div class="col-4">
                      <div class="col-12 btn-outline-warning" onclick="Cards.create_card(<?php echo e($theme->id); ?>)">
                            <br>
                            <img class="img-fluid theme-keypl mx-auto d-block" src="<?php echo e(asset('images/'.$theme->image)); ?>" alt="<?php echo e($theme->name); ?>">
                            <br>
                      </div>
                    </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
           </div>  
        </div>
  </div>
</div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/create.blade.php ENDPATH**/ ?>