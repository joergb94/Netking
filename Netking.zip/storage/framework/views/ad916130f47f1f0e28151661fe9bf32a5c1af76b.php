
    
    <div class="col-12 theme<?php echo e($data['themes_id']); ?>-padding <?php echo e($theme_shape); ?>">
        <div class="card <?php echo $card_style['divs_shape']  == 1?'div-rounded':''; ?>">
            <br>    
            <?php echo $ci['card_detail']['description']; ?>

            <br>
        </div>
      
    </div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/itemsKeypl/div4.blade.php ENDPATH**/ ?>