
            <div class="row justify-content-between">
                <?php if(isset($cardItems[0])): ?>
                <div class="col-12 dashed drop theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[0]['card_detail']->id); ?>" >
                      <div class="drag"  id="drag<?php echo e($cardItems[0]['card_detail']->id); ?>">
                        <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[0]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                        <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[0]['card_detail']->id); ?>,<?php echo e($cardItems[0]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[0]['item']->id,['ci' => $cardItems[0],'template'=>250,'theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </div>
                </div>
                <?php endif; ?>
                <?php if(isset($cardItems[1])): ?>
                        <?php if(isset($cardItems[1]['item'])): ?>
                                <div class="col-12  drop theme1-col-12 theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[1]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[1]['card_detail']->id); ?>">
                                                <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[1]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[1]['card_detail']->id); ?>,<?php echo e($cardItems[1]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[1]['item']->id,['ci' => $cardItems[1],'template'=>250,'theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                </div>
                        <?php else: ?>
                                <div class="col-12  drop theme1-col-12  theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>"  >
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[1]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div> 
                        <?php endif; ?>
                <?php endif; ?>
                <?php if(isset($cardItems[2])): ?>
                        <?php if(isset($cardItems[2]['item'])): ?>
                                <div class="col-6  dashed drop theme1-col-6 theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[2]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[2]['card_detail']->id); ?>">
                                                <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[2]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[2]['card_detail']->id); ?>,<?php echo e($cardItems[2]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[2]['item']->id,['ci' => $cardItems[2],'template'=>305,'theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                </div>
                        <?php else: ?>
                                <div class="col-6  drop theme1-col-6  theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>"  >
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[2]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div> 
                        <?php endif; ?>
                <?php endif; ?>
                <div class="col-6 theme1-col-6">
                    <div class="row">
                        <?php if(isset($cardItems[3])): ?>
                            
                                <div class="col-12  dashed drop theme1-col-social theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>"  >
                                        <div class="drag"  id="drag<?php echo e($cardItems[3]['card_detail']->id); ?>">
                                                <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[3]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[3]['card_detail']->id); ?>,<?php echo e($cardItems[3]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[3]['item']->id,['ci' => $cardItems[3],'template'=>'95','theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                
                                </div>
                        <?php endif; ?>
                        <?php if(isset($cardItems[4])): ?>
                                <?php if(isset($cardItems[4]['item'])): ?>
                                        <div class="col-12 dashed drop theme1-col theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[4]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                                <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[4]['card_detail']->id); ?>">
                                                        <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[4]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                        <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[4]['card_detail']->id); ?>,<?php echo e($cardItems[4]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[4]['item']->id,['ci' => $cardItems[4],'template'=>'95','theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                        </div>
                                <?php else: ?>
                                        <div class="col-12  drop theme1-col   theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>"  >
                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[4]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div> 
                                <?php endif; ?>
                    
                        <?php endif; ?>
                        <?php if(isset($cardItems[5])): ?>
                        
                                <?php if(isset($cardItems[5]['item'])): ?>
                                        <div class="col-12  dashed drop theme1-col theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[5]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                                <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[5]['card_detail']->id); ?>">
                                                        <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[5]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                        <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[5]['card_detail']->id); ?>,<?php echo e($cardItems[5]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[5]['item']->id,['ci' => $cardItems[5],'template'=>'95','theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                
                                        </div>
                                <?php else: ?>
                                        <div class="col-12  drop theme1-col   theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>"  >
                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[5]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div> 
                                <?php endif; ?>
                        <?php endif; ?>
                     </div>
                </div>
                <?php for($i = 6; $i < count($cardItems); $i += 4): ?>
                        <?php if(isset($cardItems[$i])): ?>
                        <div class="col-6 dashed drop theme1-col-6 theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[$i]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i]['card_detail']->id); ?>">
                                        <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                        <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i]['card_detail']->id); ?>,<?php echo e($cardItems[$i]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i]['item']->id,['ci' => $cardItems[$i],'template'=>305,'theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-6 theme1-col-6">
                        <div class="row">
                                <?php if(isset($cardItems[$i+1])): ?>
                                <div class="col-12  dashed drop theme1-col theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[$i+1]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+1]['card_detail']->id); ?>">
                                                <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+1]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+1]['card_detail']->id); ?>,<?php echo e($cardItems[$i+1]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+1]['item']->id,['ci' => $cardItems[$i+1],'template'=>'95','theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                        
                                </div>
                                <?php endif; ?>
                                <?php if(isset($cardItems[$i+2])): ?>
                                <div class="col-12  dashed drop theme1-col theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[$i+2]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+2]['card_detail']->id); ?>">
                                                <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+2]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+2]['card_detail']->id); ?>,<?php echo e($cardItems[$i+2]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+2]['item']->id,['ci' => $cardItems[$i+2],'template'=>'95','theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                        
                                </div>
                                <?php endif; ?>
                                <?php if(isset($cardItems[$i+3])): ?>
                                <div class="col-12  dashed drop theme1-col theme<?php echo e($data['themes_id']); ?>-padding" id="drop<?php echo e($cardItems[$i+3]['card_detail']->id); ?>"  ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+3]['card_detail']->id); ?>">
                                                <button class="btn btn-warning  btn-circle top-right btn-update-item" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+3]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                                <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+3]['card_detail']->id); ?>,<?php echo e($cardItems[$i+3]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+3]['item']->id,['ci' => $cardItems[$i+3],'template'=>'95','theme_shape'=>'theme1-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                </div>
                                <?php endif; ?>
                        </div>
                        </div>
                <?php endfor; ?>
            </div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/themes/theme1.blade.php ENDPATH**/ ?>