
<div class="col-12">
    <div class="row justify-content-center" >
        <div class="col-12">
            <div class="">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="col-12 col-sm-4 mx-auto d-block">
                                <img class="img-fluid image-start" src="<?php echo e(asset('img/name.png')); ?>" alt="">
                            </div>
                        </div>
                       <div class="col-12">
                        <div class="col-12 col-sm-4 mx-auto d-block">
                                <h1>Bienvenidx a keypl</h1>
                                <p>Comencemos por el inicio, nos gustari saber ¿Cual tu nombre?</p>

                                            <div class="form-group form-floating-label">
                                                <input id="name" type="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> input-border-bottom" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                                <label for="username" class="placeholder">MI NOMBRE ES</label>
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                            </div>
                       </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/getstart/items/name.blade.php ENDPATH**/ ?>