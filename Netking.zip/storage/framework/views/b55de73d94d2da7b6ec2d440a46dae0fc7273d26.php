
<div class="bg-search-keypls text-center">
<button type="button" class="btn btn-warning btn-circle top-right" id="mode-delete" onclick="transactions.mode_delete()" value="1" ><i class="fas fa-pen"></i></button>
    <h1><?php echo e($account->name); ?> <?php echo e($account->last_name); ?></h1>
      <?php echo $__env->make('Friends.items.itemsGroup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="form-group col-10 mx-auto d-block">
        <div class="inner-addon right-addon">
          <i class="glyphicon glyphicon-search"><i class="fas fa-search"></i></i>
          <input type="text" class="form-control search-query" id="search" placeholder="Search" />
        </div>
</div>
<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Friends/items/search.blade.php ENDPATH**/ ?>