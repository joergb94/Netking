<div class="row justify-content-between <?php echo e($theme_shape); ?>">
        <?php if($data['themes_id'] == 3): ?>
                <div class="col-12 text-center mx-auto d-block theme<?php echo e($data['themes_id']); ?>-padding" id="social">
                    <?php if(isset($data['card_network'])): ?>
                    <?php if($card_style['button_style'] == 0): ?>
                        <?php $__currentLoopData = $data['card_network']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="btn btn-link-keyp-social <?php echo e($btn_shape); ?> btn-social-icon keypl-btn-social theme3-padding-btn" target="_blank" href="<?php echo e($item['url']); ?>" >
                                <span class="<?php echo e($item['social_network']['icon']); ?>  keypl-text-social"></span>
                                <input type="hidden" id="cutom-social-token<?php echo e($item['id']); ?>" value="<?php echo e($ci['card_detail']['id']); ?>">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $data['card_network']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="btn btn-link-keyp-social <?php echo e($btn_shape); ?> btn-social-icon <?php echo e($item['social_network']['btn_network']); ?> theme3-padding-btn" target="_blank" href="<?php echo e($item['url']); ?>" >
                                <span class="<?php echo e($item['social_network']['icon']); ?>"></span>
                                <input type="hidden" id="cutom-social-token<?php echo e($item['id']); ?>" value="<?php echo e($ci['card_detail']['id']); ?>">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endif; ?>
                    <?php endif; ?>  
                </div>
        <?php else: ?>
                <div class="col-12 text-center mx-auto d-block theme<?php echo e($data['themes_id']); ?>-padding" id="social">
                    <?php if(isset($data['card_network'])): ?>
                    <?php if($card_style['button_style'] == 0): ?>
                        <?php $__currentLoopData = $data['card_network']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="btn btn-link-keyp-socialtheme-<?php echo e($data['themes_id']); ?>-btn-rounded btn-social-icon  theme<?php echo e($data['themes_id']); ?>-button-col-social keypl-btn-social"  target="_blank" href="<?php echo e($item['url']); ?>">
                                <span class="<?php echo e($item['social_network']['icon']); ?> keypl-text-social theme<?php echo e($data['themes_id']); ?>-icon-social"></span>
                                <input type="hidden" id="cutom-social-token<?php echo e($item['id']); ?>" value="<?php echo e($ci['card_detail']['id']); ?>">
                            
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $data['card_network']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="btn btn-link-keyp-socialtheme-<?php echo e($data['themes_id']); ?>-btn-rounded btn-social-icon btn-social-icon-padding   theme<?php echo e($data['themes_id']); ?>-button-col-social  <?php echo e($item['social_network']['btn_network']); ?>" target="_blank" href="<?php echo e($item['url']); ?>">
                                <span class="<?php echo e($item['social_network']['icon']); ?> theme<?php echo e($data['themes_id']); ?>-icon-social"></span>
                                <input type="hidden" id="cutom-social-token<?php echo e($item['id']); ?>" value="<?php echo e($ci['card_detail']['id']); ?>">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                     
        
        <?php endif; ?>
</div><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Keypls/itemsUpdate/itemsKeypl/div2.blade.php ENDPATH**/ ?>