
<?php $__env->startSection('style'); ?>
 <style>
  body {
      background-color:#e6e6e6;
    }
 </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-inner">
<div id="index_blade">
  <div class="card-body">
    <?php echo $__env->make('Profile.items.contentProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="loading" style="display:none" class="col-sm-12 text-center">
      </br></br></br>
      <div class="col-sm-12">
        <h2>Loading...</h2>
      </div>
      <div class="spinner-grow text-muted"></div>
      <div class="spinner-grow text-primary"></div>
      <div class="spinner-grow text-info"></div>
      <div class="spinner-grow text-danger"></div>
      <div class="spinner-grow text-secondary"></div>
      </br></br></br></br>
    </div> 
  </div>
  <!--card-body-->
</div>
<!--card-->


<!-- show_blade -->
<div id="show_blade" style="display:none">
  <div id="card_show"></div>
</div>
</div>
<!-- Passing BASE URL to AJAX -->
<input id="url" type="hidden" value="<?php echo e(\Request::url()); ?>">
<input id="baseUrl" type="hidden" value="<?php echo e(\Request::root()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('js/actions/Profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Profile/index.blade.php ENDPATH**/ ?>