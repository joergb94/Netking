

  
            <div class="row justify-content-between">
                    <?php if(isset($cardItems[0])): ?>
                        <?php if(isset($cardItems[0]['item'])): ?>
                            <div class="col-12 dashed theme2-padding theme-2" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[0]['card_detail']->id); ?>">
                                <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[0]['card_detail']->id); ?>">
                                    <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[0]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                    <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[0]['card_detail']->id); ?>,<?php echo e($cardItems[0]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                    <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[0]['item']->id,['ci' => $cardItems[0],'template'=>200,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-12  drop theme-2  theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[0]['card_detail']->id); ?>"  >
                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[0]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(isset($cardItems[1])): ?>
                        <?php if(isset($cardItems[1]['item'])): ?>
                            <div class="col-12 dashed theme2-padding-social theme-2" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[1]['card_detail']->id); ?>">
                                <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[1]['card_detail']->id); ?>">
                                    <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[1]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                    <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[1]['card_detail']->id); ?>,<?php echo e($cardItems[1]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                    <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[1]['item']->id,['ci' => $cardItems[1],'template'=>200,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-12 theme-2  drop  theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[1]['card_detail']->id); ?>"  >
                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[1]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(isset($cardItems[2])): ?>
                    <div class="col-6 theme-2" >
                        <div class="row theme-2">
                            <?php if(isset($cardItems[2])): ?>
                                <?php if(isset($cardItems[2]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-md" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[2]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[2]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[2]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[2]['card_detail']->id); ?>,<?php echo e($cardItems[2]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[2]['item']->id,['ci' => $cardItems[2],'template'=>180,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="drop col-12 theme2-col-md  theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[2]['card_detail']->id); ?>"  >
                                             <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[2]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div> 
                                    <?php endif; ?>
                            <?php endif; ?>
                            <?php if(isset($cardItems[3])): ?>
                                <?php if(isset($cardItems[3]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-md" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[3]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[3]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[3]['card_detail']->id); ?>,<?php echo e($cardItems[3]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[3]['item']->id,['ci' => $cardItems[3],'template'=>180,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12 theme2-col-md  theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[3]['card_detail']->id); ?>"  >
                                        <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[3]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($cardItems[4])): ?>
                    <div class="col-6 theme-2">
                        <div class="row theme-2">
                            <?php if(isset($cardItems[4])): ?>
                                <?php if(isset($cardItems[4]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-sm" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[4]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[4]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[4]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[4]['card_detail']->id); ?>,<?php echo e($cardItems[4]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[4]['item']->id,['ci' => $cardItems[4],'template'=>'100%','theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12 theme2-col-sm  theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[4]['card_detail']->id); ?>"  >
                                         <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[4]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                 <?php endif; ?>
                            <?php endif; ?>
                            <?php if(isset($cardItems[5])): ?>
                                <?php if(isset($cardItems[5]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[5]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[5]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[5]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[5]['card_detail']->id); ?>,<?php echo e($cardItems[5]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[5]['item']->id,['ci' => $cardItems[5],'template'=>200,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12 theme2-col theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[5]['card_detail']->id); ?>"  >
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[5]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(isset($cardItems[6])): ?>
                                <?php if(isset($cardItems[6]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-sm" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[6]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[6]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[6]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[6]['card_detail']->id); ?>,<?php echo e($cardItems[6]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[6]['item']->id,['ci' => $cardItems[6],'template'=>'100%','theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                        <div class="drop col-12  theme2-col-sm theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[6]['card_detail']->id); ?>"  >
                                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[6]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($cardItems[7])): ?>
                        <?php if(isset($cardItems[7]['item'])): ?>
                            <div class="col-12 dashed theme2-padding theme2-col-sm" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[7]['card_detail']->id); ?>">
                                <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[7]['card_detail']->id); ?>">
                                    <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[7]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                    <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[7]['card_detail']->id); ?>,<?php echo e($cardItems[7]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                    <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[7]['item']->id,['ci' => $cardItems[7],'template'=>95,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="drop col-12 theme2-col-sm  theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[7]['card_detail']->id); ?>"  >
                                <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[7]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php for($i = 8; $i < count($cardItems); $i += 6): ?>
                    <?php if(isset($cardItems[$i])): ?>
                    <div class="col-6 theme-2" >
                        <div class="row theme-2">
                            <?php if(isset($cardItems[$i])): ?>
                                <?php if(isset($cardItems[$i]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-md" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[$i]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i]['card_detail']->id); ?>,<?php echo e($cardItems[$i]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i]['item']->id,['ci' => $cardItems[$i],'template'=>180,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12  theme2-col-md theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[$i]['card_detail']->id); ?>"  >
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[$i]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(isset($cardItems[$i+1])): ?>
                                <?php if(isset($cardItems[$i+1]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-md" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[$i+1]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+1]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+1]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+1]['card_detail']->id); ?>,<?php echo e($cardItems[$i+1]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+1]['item']->id,['ci' => $cardItems[$i+1],'template'=>180,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12  theme2-col-md theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[$i+1]['card_detail']->id); ?>"  >
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[$i+1]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($cardItems[$i+2])): ?>
                        <div class="col-6 theme-2">
                        <div class="row theme-2">
                            <?php if(isset($cardItems[$i+2])): ?>
                                <?php if(isset($cardItems[$i+2]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-sm" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[$i+2]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+2]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+2]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+2]['card_detail']->id); ?>,<?php echo e($cardItems[$i+2]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+2]['item']->id,['ci' => $cardItems[$i+2],'template'=>'100%','theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12   theme2-col-sm theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[$i+2]['card_detail']->id); ?>"  >
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[$i+2]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(isset($cardItems[$i+3])): ?>
                                <?php if(isset($cardItems[$i+2]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[$i+3]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+3]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+3]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+3]['card_detail']->id); ?>,<?php echo e($cardItems[$i+3]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+3]['item']->id,['ci' => $cardItems[$i+3],'template'=>200,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12  theme2-col theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[$i+3]['card_detail']->id); ?>"  >
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[$i+3]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(isset($cardItems[$i+4])): ?>
                                <?php if(isset($cardItems[$i+4]['item'])): ?>
                                    <div class="col-12 dashed theme2-padding theme2-col-sm" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[$i+4]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+4]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+4]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+4]['card_detail']->id); ?>,<?php echo e($cardItems[$i+4]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+4]['item']->id,['ci' => $cardItems[$i+4],'template'=>'100%','theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="drop col-12  ttheme2-col-sm theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[$i+4]['card_detail']->id); ?>"  >
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[$i+4]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div> 
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($cardItems[$i+5])): ?>
                        <?php if(isset($cardItems[$i+5]['item'])): ?>
                            <div class="col-12 dashed theme2-padding theme2-col-sm" ondrop="dragAndDrop.drop(event)" ondragover="dragAndDrop.allowDrop(event)" id="drop<?php echo e($cardItems[$i+5]['card_detail']->id); ?>">
                                        <div class="drag" draggable="true" ondragstart="dragAndDrop.drag(event)"  id="drag<?php echo e($cardItems[$i+5]['card_detail']->id); ?>">
                                            <button class="btn btn-warning  btn-circle top-right btn-update" data-toggle="tooltip" title="Editar Keypl!" onclick="Cards.edit_detail(<?php echo e($cardItems[$i+5]['card_detail']->id); ?>)"><i class='fas fa-edit'></i></button>
                                            <button type="button" class="btn btn-danger btn-circle top-right btn-delete-item" style="display:none" onclick="Cards.delete_item(<?php echo e($cardItems[$i+5]['card_detail']->id); ?>,<?php echo e($cardItems[$i+5]['card_detail']->card_id); ?>)" > <i class="fa fa-trash"></i></button>
                                            <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.div'.$cardItems[$i+5]['item']->id,['ci' => $cardItems[$i+5],'template'=>95,'theme_shape'=>'theme2-shape'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                            </div>
                        <?php else: ?>
                            <div class="drop col-12  ttheme2-col-sm theme<?php echo e($data['themes_id']); ?>-padding"  id="drop<?php echo e($cardItems[$i+5]['card_detail']->id); ?>"  >
                                    <?php echo $__env->make('Cards.itemsUpdate.itemsKeypl.defaultDiv',['id' => $cardItems[$i+5]['card_detail']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php endfor; ?>
            </div>

<?php /**PATH C:\Users\PC\Documents\GitHub\Netking\resources\views/Cards/itemsUpdate/themes/theme2.blade.php ENDPATH**/ ?>