					
					<div class="row padding-home">
						<div class="col-12">
							@include('home.items.search')
						</div>
						<div class="col-12">
							@include('home.items.content-keypls')
						</div>
					</div>
		
