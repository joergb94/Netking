<div class="col-12">
    <div class="row justify-content-center" >
        <div class="col-12">
            <div class="">
                <div class="card-body ">
                    <div class="row ">
                        <div class="col-12">
                            <div class="col-12 col-sm-4 mx-auto d-block">
                                <img class="img-fluid image-start" src="{{asset('img/start.png')}}" >
                            </div> 
                        </div>
                        <div class="col-12">
                            <div class="col-12 col-sm-4 mx-auto d-block">
                                <h1>¡Ya casi estamos!</h1>
                                <p>Hemos creado la base de tu perfil, pero Keypl no sería nada sin la esencia de cada persona.</p>
                                <p>¿Te gustaría personalizar ahora tu tarjeta de contacto?</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>