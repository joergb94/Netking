<div class="col-12 btn btn-light button-default div-rounded" onclick ="Cards.show_add_item_type({{$id}})">
    <h1 class="centered-btn" ><i class="fas fa-plus"></i></h1>
</div>