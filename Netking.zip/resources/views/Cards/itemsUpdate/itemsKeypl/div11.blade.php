
    <div class="col-12 theme{{$data['themes_id']}}-padding text-center mx-auto d-block">
        <a class="btn {{$card_style['button_style'] == 0? 'keypl-btn':'keypl-btn-full'}} btn-block {{$btn_shape}}" target="_blank" href="{{$ci['card_detail']['description']}}" >
            <h3 style="font-family:{{$text_font->name}};">{!!$ci['card_detail']['name']!!}</h3>
        </a>
    </div>
   

