
  <div class="col-12 mx-auto d-block {!! $card_style['divs_shape']  == 1?'div-rounded':''!!} theme{{$data['themes_id']}}-padding {{$theme_shape}}">
    <blockquote class="twitter-tweet "   onmousedown="return false">
      <p lang="en" dir="ltr">twit</p>&mdash; keypls 
      <a href="{{$ci['card_detail']['description']}}?ref_src=twsrc%5Etfw">
      January 17, 2022</a>
      </blockquote>
      <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
  </div>
