
    <div class="row justify-content-between bg-white {!! $card_style['divs_shape']  == 1?'div-rounded':''!!} theme{{$data['themes_id']}}-padding {{$theme_shape}}">
        <div class="col-12 "   onmousedown="return false">
            {!!$ci['card_detail']['description']!!}
        </div>
    </div>

