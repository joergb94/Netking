
    
    <div class="col-12 theme{{$data['themes_id']}}-padding {{$theme_shape}}">
        <div class="card {!! $card_style['divs_shape']  == 1?'div-rounded':''!!}">
            <br>    
            {!!$ci['card_detail']['description']!!}
            <br>
        </div>
      
    </div>
