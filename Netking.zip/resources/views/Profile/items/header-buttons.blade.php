<div class="btn-toolbar float-right" role="toolbar" aria-label="@lang('labels.general.toolbar_btn_groups')">
    <div class="col-sm-12">
      <div class="row">
          <div class="col-sm-6">
    
          </div>
      </div>
    </div>
  </div>