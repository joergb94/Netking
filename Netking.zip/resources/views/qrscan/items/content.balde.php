<div id ="index_table">
  <div class="row">
    <div id="qr-reader" class="col-12"></div>

    <div class="input-group mb-3">
    <div class="input-group-prepend">
      <span class="input-group-text"><i class="fa fa-qrcode"></i></span>
    </div>
    <input type="text" id="qr-reader-results" class="form-control" placeholder="code">
  </div>

  </div>
</div>